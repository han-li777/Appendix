package novel.mzx.com.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MyDateConvert {
    public static Date dotStandStrToDate(String dotStr) {
        try
        {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
            return sdf.parse(dotStr);
        }catch (ParseException ex)
        {
            return null;
        }
    }

    public static Date dotEnStrToDate(String dotStr) {
        try
        {
            SimpleDateFormat sdf = new SimpleDateFormat("dd MMM,yyyy", Locale.UK);
            return sdf.parse(dotStr);
        }catch (ParseException ex)
        {
            return null;
        }
    }

    public static String dotStrToEn(String dotStr)
    {
        Date dd = dotStandStrToDate(dotStr);
        if(dd == null)
            return null;
        SimpleDateFormat df = new SimpleDateFormat("dd MMM,yyyy", Locale.UK);
        //df.setTimeZone(new java.util.SimpleTimeZone(0, "GMT"));
        return df.format(dd);
    }
}

package novel.mzx.com.fragment;

import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;

import butterknife.BindView;
import novel.mzx.com.R;
import novel.mzx.com.base.BaseFragment;


/**
 * Created by admin on 2019/11/18.
 */

public class HomeFragment extends BaseFragment{

    @BindView(R.id.swipe_layout)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @BindView(R.id.mIv)
    ImageView mIv;

    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;


    @Override
    public int getLayoutResID() {
        return R.layout.activity_hotel_details;
    }

    @Override
    public void initView(View view) {
        super.initView(view);

    }

    @Override
    public void initListener() {
        super.initListener();

    }




}

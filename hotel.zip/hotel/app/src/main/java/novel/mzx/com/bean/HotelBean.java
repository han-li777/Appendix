package novel.mzx.com.bean;

import java.util.List;

public class HotelBean {

    private boolean success;

    private String msg;

    private List<Obj> obj ;

    private String attributes;

    private String count;

    public void setSuccess(boolean success){
        this.success = success;
    }
    public boolean getSuccess(){
        return this.success;
    }
    public void setMsg(String msg){
        this.msg = msg;
    }
    public String getMsg(){
        return this.msg;
    }
    public void setObj(List<Obj> obj){
        this.obj = obj;
    }
    public List<Obj> getObj(){
        return this.obj;
    }
    public void setAttributes(String attributes){
        this.attributes = attributes;
    }
    public String getAttributes(){
        return this.attributes;
    }
    public void setCount(String count){
        this.count = count;
    }
    public String getCount(){
        return this.count;
    }

    public class Obj {
        private int hotelInfoId;

        private String hotelInfoName;

        private String hotelInfoAddress;

        private String hotelInfoImg;

        public void setHotelInfoId(int hotelInfoId){
            this.hotelInfoId = hotelInfoId;
        }
        public int getHotelInfoId(){
            return this.hotelInfoId;
        }
        public void setHotelInfoName(String hotelInfoName){
            this.hotelInfoName = hotelInfoName;
        }
        public String getHotelInfoName(){
            return this.hotelInfoName;
        }
        public void setHotelInfoAddress(String hotelInfoAddress){
            this.hotelInfoAddress = hotelInfoAddress;
        }
        public String getHotelInfoAddress(){
            return this.hotelInfoAddress;
        }
        public void setHotelInfoImg(String hotelInfoImg){
            this.hotelInfoImg = hotelInfoImg;
        }
        public String getHotelInfoImg(){
            return this.hotelInfoImg;
        }

    }
}

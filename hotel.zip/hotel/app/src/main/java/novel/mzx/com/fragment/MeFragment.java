package novel.mzx.com.fragment;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.URLUtil;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;


import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import android.net.*;

import com.lzy.okgo.OkGo;

import butterknife.BindView;
import novel.mzx.com.R;
import novel.mzx.com.activity.EditInformationActivity;
import novel.mzx.com.activity.LoginActivity;
import novel.mzx.com.activity.MyOrderActivity;
import novel.mzx.com.base.BaseFragment;

import novel.mzx.com.constants.Api;
import novel.mzx.com.utils.SPUtil;
import novel.mzx.com.views.XCRoundImageView;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class MeFragment extends BaseFragment implements View.OnClickListener {

    @BindView(R.id.rv_user_data)
    RelativeLayout rv_user_data;

    @BindView(R.id.ll_account)
    LinearLayout ll_account;

    @BindView(R.id.ll_editInfo)
    LinearLayout ll_editInfo;

    @BindView(R.id.ll_out)
    LinearLayout ll_out;


    @BindView(R.id.tv_zhuan_ye)
    TextView tv_zhuan_ye;

    @BindView(R.id.tv_user_name)
    TextView tv_user_name;

    @BindView(R.id.iv_user_head)
    XCRoundImageView iv_user_head;

    @Override
    public int getLayoutResID() {

        return R.layout.fragment_my;
    }

    @Override
    public void initView(View view) {
        super.initView(view);
    }

    @Override
    public void initListener() {
        super.initListener();
        rv_user_data.setOnClickListener(this);
        ll_account.setOnClickListener(this);
        ll_out.setOnClickListener(this);
        ll_editInfo.setOnClickListener(this);

        freshDataView();

        registMeBroadListener();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.ll_account:
                Intent intent = new Intent(getActivity(), MyOrderActivity.class);
                startActivity(intent);
                break;

            case R.id.ll_editInfo:
                Intent editIntent = new Intent(getActivity(), EditInformationActivity.class);
                startActivity(editIntent);
                break;

            case R.id.ll_out:
                SPUtil.getInstance().putString("memberId","");
                SPUtil.getInstance().putString("username","");
                Intent intent1 = new Intent(getActivity(),LoginActivity.class);
                startActivity(intent1);
                getActivity().finish();
                break;

        }
    }


    @Override
    public void initData() {
        super.initData();
    }

    private void freshDataView()
    {
        String phone = SPUtil.getInstance().getString("phone");
        String sex = SPUtil.getInstance().getString("sex");

        String headUrl = SPUtil.getInstance().getString("userHead");
        if(headUrl != null) {
            headUrl = Api.mainImgHost + headUrl;
            showHeadImgFromWeb(headUrl);
        }

        tv_user_name.setText("Phone: "+phone+"  sex: "+sex);
        tv_zhuan_ye.setText(SPUtil.getInstance().getString("username"));
    }

    private Handler handler = new Handler(){
        public void handleMessage(Message msg){
            Bitmap bitmap = (Bitmap)msg.obj;
            iv_user_head.setImageBitmap(bitmap);
        }
    };

    private void showHeadImgFromWeb(String imgUrl){
        OkHttpClient httpClient = new OkHttpClient();
        Request request = new Request.Builder()
                .url(imgUrl)
                .build();
        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {}

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                InputStream inputStream = response.body().byteStream();
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                if(bitmap != null){
                    Message msg = new Message();
                    msg.obj = bitmap;
                    handler.sendMessage(msg);
                }

            }
        });
    }

    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            freshDataView();
        }
    };

    private void registMeBroadListener() {
        IntentFilter myIntentFilter = new IntentFilter();
        myIntentFilter.addAction("refreshInformation");
        getActivity().registerReceiver(broadcastReceiver, myIntentFilter);
    }
}

package novel.mzx.com.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.StringCallback;
import com.lzy.okgo.model.Response;
import com.zhy.adapter.recyclerview.CommonAdapter;
import com.zhy.adapter.recyclerview.base.ViewHolder;

import org.w3c.dom.Comment;

import java.util.List;

import novel.mzx.com.R;
import novel.mzx.com.activity.CommentActivity;
import novel.mzx.com.bean.CodeBean;
import novel.mzx.com.bean.HotelBean;
import novel.mzx.com.bean.OrderBean;
import novel.mzx.com.constants.Api;
import novel.mzx.com.utils.JSONUtils;
import novel.mzx.com.utils.SPUtil;
import novel.mzx.com.utils.ToastUtils;
import novel.mzx.com.views.CustomDialog;


/**
 * Created by Administrator on 2019/4/17 0017.
 */

public class OrderAdapter extends CommonAdapter<OrderBean.Obj> {
    Context mContext;

    public OrderAdapter(Context context, int layoutId, List<OrderBean.Obj> datas) {
        super(context, layoutId, datas);
        mContext = context;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void convert(ViewHolder holder, final OrderBean.Obj s, int position) {


        holder.setText(R.id.news_title,s.getHotelInfoName());
        holder.setText(R.id.news_title2,"room number:"+s.getHotelMemberRoomRoomNum());
        holder.setText(R.id.tv_start,"start time:"+s.getHotelMemberRoomStartTime());
        holder.setText(R.id.tv_end,"end time:"+s.getHotelMemberRoomEndTime());
        holder.setText(R.id.tv_order_price, "$" + s.getHotelMemberRoomPrice());
        holder.setText(R.id.tv_orderNum,"order number:"+s.getHotelMemberRoomStartTime().replace(".","")+s.getHotelRoomNum());
        /*if(Integer.valueOf(s.getHotelMemberRoomState()) == 2)
            holder.setVisible(R.id.tv_out, false);*/
        ImageView news_img = holder.getConvertView().findViewById(R.id.news_img);
        Glide.with(mContext).load("https://img.ivsky.com/img/tupian/pre/201107/23/beijing_bandaojiudian-004.jpg").into(news_img);
        int tt = Integer.valueOf(s.getHotelMemberRoomState());
        if(Integer.valueOf(s.getHotelMemberRoomState()) == 1) {
            holder.setOnClickListener(R.id.tv_state, new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    showDialog1(s.getHotelRoomPwd());

                }
            });
            holder.setOnClickListener(R.id.tv_out, new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String username = SPUtil.getInstance().getString("username");
                    OkGo.<String>post(Api.mainHost+Api.checkOutRoomUrl)
                            .params("memberId", s.getHotelMemberRoomId())
                            .params("hotelUserAccount",username)
                            .params("hotelInfoId",s.getHotelInfoId())
                            .params("hotelRoomNum",s.getHotelRoomNum())
                            .execute(new StringCallback() {
                                @Override
                                public void onSuccess(Response<String> response) {
                                    Log.e("Make a room reservation",response.body());
                                    CodeBean codeBean = JSONUtils.parserObject(response.body(),CodeBean.class);
                                    boolean success = codeBean.getSuccess();
                                    if(success){

                                        ToastUtils.showToast(mContext,"Check out successful!");
                                        Intent intent = new Intent();
                                        intent.setAction("refresh3");
                                        mContext.sendBroadcast(intent);
                                    }else {

                                    }
                                }

                                @Override
                                public void onError(Response<String> response) {
                                    super.onError(response);

                                }
                            });
                }
            });
        }else{
            //holder.setVisible(R.id.tv_out, false);
            holder.setText(R.id.tv_state,"Completed");
            holder.setBackgroundColor(R.id.tv_state, Color.GRAY);
            holder.setText(R.id.tv_out, "Comment");
            holder.setOnClickListener(R.id.tv_out, new View.OnClickListener(){
                @Override
                public void onClick(View view) {
                    String username = SPUtil.getInstance().getString("username");
                    Intent commentIntent = new Intent(mContext, CommentActivity.class);
                    commentIntent.putExtra("memberId", s.getHotelMemberRoomId());
                    commentIntent.putExtra("userName",username);
                    commentIntent.putExtra("roomNum", s.getHotelRoomNum());
                    mContext.startActivity(commentIntent);
                }
            });
        }
    }


    private void showDialog1(String hotelRoomNum) {

        CustomDialog dialog = new CustomDialog(mContext,R.layout.custom_dialog_pwd);
        TextView tv_01 = dialog.findViewById(R.id.tv_01);
        RelativeLayout rl_sure = dialog.findViewById(R.id.rl_sure);
        tv_01.setText(hotelRoomNum);
        rl_sure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();


    }


}

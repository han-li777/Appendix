package novel.mzx.com.activity;

import android.content.Intent;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import com.gyf.immersionbar.ImmersionBar;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.StringCallback;
import com.lzy.okgo.model.Response;


import butterknife.BindView;
import butterknife.OnClick;

import novel.mzx.com.R;
import novel.mzx.com.base.BaseActivity;
import novel.mzx.com.bean.CodeBean;
import novel.mzx.com.constants.Api;
import novel.mzx.com.utils.FinishActivity;
import novel.mzx.com.utils.JSONUtils;
import novel.mzx.com.utils.SPUtil;
import novel.mzx.com.utils.StringUtils;
import novel.mzx.com.utils.ToastUtils;
import novel.mzx.com.views.InputMethodLayout;


public class LoginActivity extends BaseActivity {
    @BindView(R.id.et_phoneNum)
    EditText etPhoneNum;
    @BindView(R.id.et_password)
    EditText etPassword;

    @BindView(R.id.btn_login)
    Button btnLogin;

    @BindView(R.id.tv_find_pwd)
    TextView tv_find_pwd;


    @BindView(R.id.root)
    ScrollView scrollView;

    @BindView(R.id.rl)
    InputMethodLayout rl;

    int scrollViewHeight;




    @Override
    protected int getResourceId() {
        return R.layout.activity_login;
    }


    String update;

    @Override
    protected void initView() {
        super.initView();
        ImmersionBar.with(this).titleBar(R.id.toolbar).keyboardEnable(true).init();
        ImmersionBar.with(LoginActivity.this).keyboardEnable(false).statusBarDarkFont(true, 0.2f).navigationBarColor(R.color.btn3).init();
        String userid = SPUtil.getInstance().getString("memberId");
        if(userid == null){
            userid = "";
        }
        if(!userid.equals("")){
            Intent intent2 = new Intent(LoginActivity.this,MainActivity.class);
            startActivity(intent2);
            finish();
        }




        rl.setOnkeyboarddStateListener(new InputMethodLayout.onKeyboardsChangeListener() {
            @Override
            public void onKeyBoardStateChange(int state) {
                switch (state) {
                    case InputMethodLayout.KEYBOARD_STATE_HIDE:

                        break;
                    case InputMethodLayout.KEYBOARD_STATE_SHOW:

                        scrollView.post(new Runnable() {
                            @Override
                            public void run() {
                                scrollViewHeight = scrollView.getMeasuredWidth();

                                scrollView.scrollTo(0, 500);
                            }
                        });

                        break;

                    default:
                        break;
                }
            }
        });

        tv_find_pwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this,RegiestActivity.class);
                startActivity(intent);
                FinishActivity.addActivity(LoginActivity.this);
            }
        });


    }



    @OnClick({R.id.l_1, R.id.btn_login,R.id.iv_close})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.l_1:
                break;
            case R.id.btn_login:
                if (StringUtils.getEditTextData(etPhoneNum).isEmpty() && StringUtils.getEditTextData(etPassword).isEmpty()){
                    ToastUtils.showToast(this,"Please enter a user name or password");
                    return;
                }
                if(StringUtils.getEditTextData(etPhoneNum).isEmpty()){
                    ToastUtils.showToast(this,"Please enter one user name");
                    return;
                }

                if(StringUtils.getEditTextData(etPassword).isEmpty()){
                    ToastUtils.showToast(this,"Please input a password");
                    return;
                }
                String uname = StringUtils.getEditTextData(etPhoneNum);
                String pwd = StringUtils.getEditTextData(etPassword);
                netWorkLogin(uname,pwd);



                break;


        }
    }


    private void netWorkLogin(String uname, String pwd) {

        try {
            OkGo.<String>get(Api.mainHost+Api.loginUrl)
                    .params("hotelUserAccount",uname)
                    .params("hotelUserPwd",pwd)
                    .execute(new StringCallback() {
                        @Override
                        public void onSuccess(Response<String> response) {
                            Log.e("login",response.body());

                            CodeBean codeBean = JSONUtils.parserObject(response.body(),CodeBean.class);
                            boolean success = codeBean.getSuccess();
                            if(success){
                                ToastUtils.showToast(LoginActivity.this,"success!");
                                Intent intent2 = new Intent(LoginActivity.this,MainActivity.class);
                                startActivity(intent2);
                                SPUtil.getInstance().putString("memberId",codeBean.getObj().getHotelUserId()+"");
                                SPUtil.getInstance().putString("username",codeBean.getObj().getHotelUserAccount()+"");
                                SPUtil.getInstance().putString("phone",codeBean.getObj().getHotelUserPhone()+"");
                                SPUtil.getInstance().putString("sex",codeBean.getObj().getHotelUserGender()+"");
                                SPUtil.getInstance().putString("userHead",codeBean.getObj().getHotelUserImg()+"");
                                finish();

                            }else {
                                ToastUtils.showToast(LoginActivity.this,"false!");
                            }
                        }

                        @Override
                        public void onError(Response<String> response) {
                            super.onError(response);

                        }
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if(update != null){
                Intent intent = new Intent(LoginActivity.this,MainActivity.class);
                startActivity(intent);
                finish();
            }else {
                finish();
            }
        }

        return super.onKeyDown(keyCode, event);

    }


}

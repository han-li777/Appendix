package novel.mzx.com.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.gyf.immersionbar.ImmersionBar;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.StringCallback;
import com.lzy.okgo.model.Response;

import java.util.List;

import butterknife.BindView;
import novel.mzx.com.R;
import novel.mzx.com.adapter.RoomAdapter;
import novel.mzx.com.base.BaseActivity;
import novel.mzx.com.bean.RoomBean;
import novel.mzx.com.constants.Api;
import novel.mzx.com.utils.JSONUtils;
import novel.mzx.com.utils.MyDateConvert;
import novel.mzx.com.utils.SPUtil;

public class HotelDeatilsActivity extends BaseActivity {

    String hotelId;
    String hotelName;
    String hotelAddress;
    String hotelImage;

    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;

    @BindView(R.id.mIv)
    ImageView mIv;

    @BindView(R.id.tv_left)
    TextView tv_left;

    @BindView(R.id.tv_right)
    TextView tv_right;

    @BindView(R.id.iv_back)
    ImageView iv_back;

    @BindView(R.id.tv_choose)
    TextView tv_choose;

    private LinearLayoutManager mLinearLayoutManager;

    private RoomAdapter roomAdapter;

    @Override
    protected int getResourceId() {
        return R.layout.activity_hotel_details;
    }

    @Override
    protected void initView() {
        super.initView();
        ImmersionBar.with(this).titleBar(R.id.toolbar).keyboardEnable(true).init();
        ImmersionBar.with(HotelDeatilsActivity.this).keyboardEnable(false).statusBarDarkFont(true, 0.2f).navigationBarColor(R.color.btn3).init();
        mLinearLayoutManager = new LinearLayoutManager(this, LinearLayout.VERTICAL,false);
        recyclerView.setLayoutManager(mLinearLayoutManager);
        hotelId = getIntent().getStringExtra("hotelId");
        hotelName = getIntent().getStringExtra("hotelName");
        hotelAddress = getIntent().getStringExtra("hotelAddress");
        hotelImage = getIntent().getStringExtra("hotelImage");
        //String imagUrl = "https://img.ivsky.com/img/tupian/pre/201107/23/beijing_bandaojiudian-001.jpg";
        String imagUrl = Api.mainImgHost + hotelImage;
        Glide.with(this).load(imagUrl).into(mIv);
        tv_left.setText(hotelName);
        tv_right.setText(hotelAddress);

        //SPUtil.getInstance().putString("start",start);
        //SPUtil.getInstance().putString("end",end);
        SPUtil.getInstance().putInt("days",0);

        registerBoradcastReceiver();

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        tv_choose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HotelDeatilsActivity.this,DateSelectActivity.class);
                startActivityForResult(intent,100);
            }
        });

    }

    public void registerBoradcastReceiver() {
        IntentFilter myIntentFilter = new IntentFilter();
        myIntentFilter.addAction("refresh2");
        //注册广播
        registerReceiver(broadcastReceiver, myIntentFilter);
    }


    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            getRoomInfo();
        }
    };



    @Override
    protected void initData() {
        super.initData();
        getRoomInfo();
    }

    private void getRoomInfo() {
        OkGo.<String>post(Api.mainHost+Api.hotelRoomListUrl)
                .params("hotelRoomInfoId",hotelId)
                .execute(new StringCallback() {
                    @Override
                    public void onSuccess(Response<String> response) {
                        Log.e("Room list",response.body());

                        RoomBean roomBean = JSONUtils.parserObject(response.body(),RoomBean.class);
                        boolean success = roomBean.getSuccess();
                        if(success){
                            int days = SPUtil.getInstance().getInt("days",0);
                            if(days > 0)
                                roomBean.filterObj(start, end);

                            List<RoomBean.Obj> obj = roomBean.getObj();
                            String count = roomBean.getCount();
                            SPUtil.getInstance().putString("roomCount",count);
                            roomAdapter = new RoomAdapter(HotelDeatilsActivity.this,R.layout.item_room,obj,hotelId);
                            recyclerView.setAdapter(roomAdapter);


                        }else {

                        }
                    }

                    @Override
                    public void onError(Response<String> response) {
                        super.onError(response);

                    }
                });
    }

    private String start;
    private String end;
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 100 && resultCode == DateSelectActivity.RERSULT_CODE) {
            Bundle extras = data.getExtras();
            if (extras!=null) {
                start = extras.getString(DateSelectActivity.START);
                end = extras.getString(DateSelectActivity.END);
                int days = extras.getInt(DateSelectActivity.DAY_NUMBER);

                tv_choose.setText("start time："+
                        MyDateConvert.dotStrToEn(start) +
                        "   end time："+MyDateConvert.dotStrToEn(end) +
                        "   days："+days);
                if(start !=null){
                    SPUtil.getInstance().putString("start",start);
                }

                if(end !=null){
                    SPUtil.getInstance().putString("end",end);
                }
                if(days !=0){
                    SPUtil.getInstance().putInt("days",days);

                    getRoomInfo();
                }
            }
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(broadcastReceiver);
    }
}

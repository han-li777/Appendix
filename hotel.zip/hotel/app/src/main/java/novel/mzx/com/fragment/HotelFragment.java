package novel.mzx.com.fragment;

import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;

import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.StringCallback;
import com.lzy.okgo.model.Response;
import com.zhy.adapter.recyclerview.MultiItemTypeAdapter;

import java.util.List;

import butterknife.BindView;
import novel.mzx.com.R;
import novel.mzx.com.activity.HotelDeatilsActivity;
import novel.mzx.com.activity.LoginActivity;
import novel.mzx.com.activity.MainActivity;
import novel.mzx.com.adapter.HotelAdapter;
import novel.mzx.com.base.BaseFragment;
import novel.mzx.com.bean.HotelBean;
import novel.mzx.com.constants.Api;
import novel.mzx.com.utils.JSONUtils;
import novel.mzx.com.utils.SPUtil;
import novel.mzx.com.utils.ToastUtils;


public class HotelFragment extends BaseFragment {

    @BindView(R.id.tabLayout)
    TabLayout tabLayout;

    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;

    @BindView(R.id.toolbar)
    Toolbar toolbar;

    @BindView(R.id.ll_search)
    LinearLayout ll_search;

    private HotelAdapter hotelAdapter;
    @Override
    public int getLayoutResID() {

        return R.layout.fragment_three;
    }

    @Override
    public void initView(View view) {
        super.initView(view);

        toolbar.setTitle("");


        tabLayout.addTab(tabLayout.newTab().setText("Hotel display"));
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override  
            public void onTabSelected(TabLayout.Tab tab) {

                int position = tab.getPosition();
                if(position == 0){
                    toolbar.setBackground(getResources().getDrawable(R.drawable.shape_cool));
                    tabLayout.setBackground(getResources().getDrawable(R.drawable.shape_cool));
                    getDatas();
                }else {
                    toolbar.setBackground(getResources().getDrawable(R.drawable.shape_login));
                    tabLayout.setBackground(getResources().getDrawable(R.drawable.shape_login));

                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });



    }



    @Override
    public void initListener() {
        super.initListener();

    }



    @Override
    public void initData() {

        getDatas();
    }

    private void getDatas() {
        OkGo.<String>get(Api.mainHost+Api.hotelInfoListUrl)
                .execute(new StringCallback() {
                    @Override
                    public void onSuccess(Response<String> response) {
                        Log.e("Hotel list",response.body());

                        HotelBean hotelBean = JSONUtils.parserObject(response.body(),HotelBean.class);
                        boolean success = hotelBean.getSuccess();
                        if(success){
                            List<HotelBean.Obj> obj = hotelBean.getObj();
                            hotelAdapter = new HotelAdapter(getActivity(),R.layout.item_home_hotel,obj);
                            recyclerView.setAdapter(hotelAdapter);
                            hotelAdapter.setOnItemClickListener(new MultiItemTypeAdapter.OnItemClickListener() {
                                @Override
                                public void onItemClick(View view, RecyclerView.ViewHolder holder, int position) {
                                    Intent intent = new Intent(getActivity(), HotelDeatilsActivity.class);
                                    intent.putExtra("hotelId",obj.get(position).getHotelInfoId()+"");
                                    intent.putExtra("hotelName",obj.get(position).getHotelInfoName()+"");
                                    intent.putExtra("hotelAddress",obj.get(position).getHotelInfoAddress()+"");
                                    intent.putExtra("hotelImage", obj.get(position).getHotelInfoImg());
                                    startActivity(intent);
                                    SPUtil.getInstance().putString("hotelId",obj.get(position).getHotelInfoId()+"");
                                }

                                @Override
                                public boolean onItemLongClick(View view, RecyclerView.ViewHolder holder, int position) {
                                    return false;
                                }
                            });
                        }else {

                        }
                    }

                    @Override
                    public void onError(Response<String> response) {
                        super.onError(response);

                    }
                });
    }
}

package novel.mzx.com.activity;


import android.support.v4.app.FragmentTransaction;
import android.widget.FrameLayout;
import android.widget.RadioGroup;


import com.gyf.immersionbar.ImmersionBar;



import butterknife.BindView;
import novel.mzx.com.R;
import novel.mzx.com.base.BaseActivity;
import novel.mzx.com.fragment.HomeFragment;
import novel.mzx.com.fragment.HotelFragment;
import novel.mzx.com.fragment.MeFragment;


public class MainActivity extends BaseActivity {

    @BindView(R.id.frameLayout)
    FrameLayout frameLayout;

    @BindView(R.id.main_radioGroup)
    RadioGroup mainRadioGroup;


    HomeFragment homeFragment;


    HotelFragment threeFragment;

    MeFragment meFragment;

    @Override
    protected int getResourceId() {
        return R.layout.activity_main;
    }

    @Override
    protected void initView() {
        super.initView();
    }


    @Override
    protected void initData() {
        super.initData();
        showFragment(0);
    }

    @Override
    protected void initListener() {
        super.initListener();

        mainRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
                switch (checkedId) {
                    case R.id.rb_home_page:
                        showFragment(0);
                        ImmersionBar.with(MainActivity.this).keyboardEnable(false).statusBarDarkFont(false).navigationBarColor(R.color.colorPrimary).init();
                        break;
                    case R.id.rb_three:
                        showFragment(1);
                        ImmersionBar.with(MainActivity.this).keyboardEnable(false).statusBarDarkFont(true, 0.2f).navigationBarColor(R.color.btn3).init();
                        break;
                    case R.id.rb_my:
                        showFragment(2);
                        ImmersionBar.with(MainActivity.this).keyboardEnable(false).statusBarDarkFont(true, 0.2f).navigationBarColor(R.color.btn3).init();
                        break;

                }
            }
        });
    }

    public void showFragment(int i) {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        hideFragments(ft);
        switch (i) {
            case 0:
                if (threeFragment != null)
                    ft.show(threeFragment);
                else {
                    threeFragment = new HotelFragment();
                    ft.add(R.id.frameLayout, threeFragment);
                }

                break;
            case 1:
                if (homeFragment != null)
                    ft.show(homeFragment);
                else {
                    homeFragment = new HomeFragment();
                    ft.add(R.id.frameLayout, homeFragment);
                }
                break;
            case 2:
                if (meFragment != null)
                    ft.show(meFragment);
                else {
                    meFragment = new MeFragment();
                    ft.add(R.id.frameLayout, meFragment);
                }
                ImmersionBar.with(this).keyboardEnable(false).statusBarDarkFont(false).navigationBarColor(R.color.colorPrimary).init();

                break;


        }
        ft.commit();
    }

    private void hideFragments(FragmentTransaction ft2) {
        if (homeFragment != null)
            ft2.hide(homeFragment);
        if (threeFragment != null)
            ft2.hide(threeFragment);
        if (meFragment != null)
            ft2.hide(meFragment);

    }


    @Override
    protected void onDestroy() {
        super.onDestroy();

    }




    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

}

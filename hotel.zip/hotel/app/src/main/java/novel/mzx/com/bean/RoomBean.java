package novel.mzx.com.bean;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import novel.mzx.com.utils.MyDateConvert;

public class RoomBean {

    private boolean success;

    private String msg;

    private List<Obj> obj ;

    private String attributes;

    private String count;

    public void setSuccess(boolean success){
        this.success = success;
    }
    public boolean getSuccess(){
        return this.success;
    }
    public void setMsg(String msg){
        this.msg = msg;
    }
    public String getMsg(){
        return this.msg;
    }
    public void setObj(List<Obj> obj){
        this.obj = obj;
    }
    public List<Obj> getObj(){
        return this.obj;
    }
    public void setAttributes(String attributes){
        this.attributes = attributes;
    }
    public String getAttributes(){
        return this.attributes;
    }
    public void setCount(String count){
        this.count = count;
    }
    public String getCount(){
        return this.count;
    }

    public void filterObj(String startStr, String endStr)
    {
        if(startStr == null || startStr.isEmpty())
            return;
        if(endStr == null || endStr.isEmpty())
            return;

        Date start = MyDateConvert.dotStandStrToDate(startStr);
        Date end = MyDateConvert.dotStandStrToDate(endStr);
        List<Obj> newObjs = new ArrayList<Obj>();
        for(Obj item : this.obj){
            if(item.getHotelRoomIsPay() == 2) {
                Date itemStart = MyDateConvert.dotEnStrToDate(item.getHotelRoomStart());
                Date itemEnd = MyDateConvert.dotEnStrToDate(item.getHotelRoomEnd());
                if(end.before(itemStart) || start.after(itemEnd))
                    newObjs.add(item);
            }else{
                newObjs.add(item);
            }
        }
        this.obj = newObjs;
    }

    public class Obj {
        private int hotelRoomId;

        private String hotelRoomNum;

        private String hotelRoomPwd;

        private int hotelRoomIsPay;

        private int hotelRoomInfoId;

        private float hotelRoomPrice;
        private String hotelRoomStart;
        private String hotelRoomEnd;
        private String hotelRoomBooker;

        public void setHotelRoomPrice(float hotelRoomPrice) { this.hotelRoomPrice = hotelRoomPrice; }
        public float getHotelRoomPrice() { return this.hotelRoomPrice; }
        public void setHotelRoomStart(String hotelRoomStart) { this.hotelRoomStart = hotelRoomStart; }
        public String getHotelRoomStart() { return this.hotelRoomStart; }
        public void setHotelRoomEnd(String hotelRoomEnd) { this.hotelRoomEnd = hotelRoomEnd; }
        public String getHotelRoomEnd() { return this.hotelRoomEnd; }
        public void setHotelRoomBooker(String hotelRoomBooker) { this.hotelRoomBooker = hotelRoomBooker; }
        public String getHotelRoomBooker() { return this.hotelRoomBooker; }

        public void setHotelRoomId(int hotelRoomId){
            this.hotelRoomId = hotelRoomId;
        }
        public int getHotelRoomId(){
            return this.hotelRoomId;
        }
        public void setHotelRoomNum(String hotelRoomNum){
            this.hotelRoomNum = hotelRoomNum;
        }
        public String getHotelRoomNum(){
            return this.hotelRoomNum;
        }
        public void setHotelRoomPwd(String hotelRoomPwd){
            this.hotelRoomPwd = hotelRoomPwd;
        }
        public String getHotelRoomPwd(){
            return this.hotelRoomPwd;
        }
        public void setHotelRoomIsPay(int hotelRoomIsPay){
            this.hotelRoomIsPay = hotelRoomIsPay;
        }
        public int getHotelRoomIsPay(){
            return this.hotelRoomIsPay;
        }
        public void setHotelRoomInfoId(int hotelRoomInfoId){
            this.hotelRoomInfoId = hotelRoomInfoId;
        }
        public int getHotelRoomInfoId(){
            return this.hotelRoomInfoId;
        }

    }
}

package novel.mzx.com.bean;

public class CodeBean {
    private boolean success;

    private String msg;

    private Obj obj;

    private String attributes;

    private String count;

    public void setSuccess(boolean success){
        this.success = success;
    }
    public boolean getSuccess(){
        return this.success;
    }
    public void setMsg(String msg){
        this.msg = msg;
    }
    public String getMsg(){
        return this.msg;
    }
    public void setObj(Obj obj){
        this.obj = obj;
    }
    public Obj getObj(){
        return this.obj;
    }
    public void setAttributes(String attributes){
        this.attributes = attributes;
    }
    public String getAttributes(){
        return this.attributes;
    }
    public void setCount(String count){
        this.count = count;
    }
    public String getCount(){
        return this.count;
    }

    public class Obj {
        private String hotelUserId;

        private String hotelUserAccount;

        private String hotelUserPwd;

        private String hotelUserName;

        private String hotelUserGender;
        private String hotelUserPhone;
        private String hotelUserImg;

        public String getHotelUserImg() { return hotelUserImg; }

        public void setHotelUserImg(String hotelUserImg) {
            this.hotelUserImg = hotelUserImg;
        }

        public String getHotelUserPhone() {
            return hotelUserPhone;
        }

        public void setHotelUserPhone(String hotelUserPhone) {
            this.hotelUserPhone = hotelUserPhone;
        }

        public void setHotelUserId(String hotelUserId){
            this.hotelUserId = hotelUserId;
        }
        public String getHotelUserId(){
            return this.hotelUserId;
        }
        public void setHotelUserAccount(String hotelUserAccount){
            this.hotelUserAccount = hotelUserAccount;
        }
        public String getHotelUserAccount(){
            return this.hotelUserAccount;
        }
        public void setHotelUserPwd(String hotelUserPwd){
            this.hotelUserPwd = hotelUserPwd;
        }
        public String getHotelUserPwd(){
            return this.hotelUserPwd;
        }
        public void setHotelUserName(String hotelUserName){
            this.hotelUserName = hotelUserName;
        }
        public String getHotelUserName(){
            return this.hotelUserName;
        }
        public void setHotelUserGender(String hotelUserGender){
            this.hotelUserGender = hotelUserGender;
        }
        public String getHotelUserGender(){
            return this.hotelUserGender;
        }

    }
}

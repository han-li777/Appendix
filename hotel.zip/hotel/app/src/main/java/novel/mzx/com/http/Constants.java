package novel.mzx.com.http;

/**
 * Created by admin on 2019/11/18.
 */

public class Constants {
    public static final String SHARE_PREFERENCE_NAME = "myNovel";
}

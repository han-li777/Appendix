package novel.mzx.com.bean;

/**
 * Created by My on 2017/10/16.
 * 判断用户状态的信息
 */

public class Result {
    public boolean sessionTerminate;
    public boolean result;
    public String reason;
}

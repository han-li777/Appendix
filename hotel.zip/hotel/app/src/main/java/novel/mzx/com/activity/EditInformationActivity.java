package novel.mzx.com.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.provider.MediaStore;

import com.gyf.immersionbar.ImmersionBar;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.StringCallback;
import com.lzy.okgo.model.Response;

import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import butterknife.BindView;
import butterknife.OnClick;
import novel.mzx.com.R;
import novel.mzx.com.base.BaseActivity;
import novel.mzx.com.bean.CodeBean;
import novel.mzx.com.constants.Api;
import novel.mzx.com.fragment.MeFragment;
import novel.mzx.com.utils.JSONUtils;
import novel.mzx.com.utils.SPUtil;
import novel.mzx.com.utils.StringUtils;
import novel.mzx.com.utils.ToastUtils;
import novel.mzx.com.views.XCRoundImageView;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

public class EditInformationActivity extends BaseActivity {
    private ImageView ivBack;
    private EditText rbPhone;
    private RadioGroup rbSex;
    private RadioButton rbSexMan;
    private RadioButton rbSexWomen;
    private Button btnSavePerson;
    private XCRoundImageView rbPersonImg;
    private Button btnSelectPic;
    private Button btnUploadPic;

    @Override
    protected int getResourceId() {
        return R.layout.activity_edit_information;
    }

    private String selectImagePath = null;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        if (requestCode == 0x1 && resultCode == RESULT_OK) {
            if (data != null) {
                Uri imgPathUri = data.getData();
                rbPersonImg.setImageURI(imgPathUri);

                String[] filePathColumn = { MediaStore.Images.Media.DATA };
                Cursor cursor = getContentResolver().query(imgPathUri, filePathColumn, null, null, null);
                cursor.moveToFirst();
                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                selectImagePath = cursor.getString(columnIndex);
                cursor.close();
                //SPUtil.getInstance().putString("imgStorePath", imgPath);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_information);

        ivBack = findViewById(R.id.iv_back);
        rbPhone = findViewById(R.id.rb_phone);
        rbSex = findViewById(R.id.rb_sex);
        rbSexMan = findViewById(R.id.rb_sex_male);
        rbSexWomen = findViewById(R.id.rb_sex_female);
        btnSavePerson = findViewById(R.id.btn_save_person);
        rbPersonImg = findViewById(R.id.rb_personImg);
        btnSelectPic = findViewById(R.id.rb_selectPic);
        btnUploadPic = findViewById(R.id.rb_uploadPic);

        String sPhone = SPUtil.getInstance().getString("phone");
        String sSex = SPUtil.getInstance().getString("sex");
        switch (sSex)
        {
            case "male":
                rbSexMan.setChecked(true);
                break;
            case "female":
                rbSexWomen.setChecked(true);
                break;
        }
        if(sPhone != null)
            rbPhone.setText(sPhone);
        String sHead = SPUtil.getInstance().getString("userHead");
        if(sHead != null) {
            sHead = Api.mainImgHost + sHead;
            showHeadImgFromWeb(sHead);
        }

        btnSelectPic.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                int hasWriteStoragePermission = ContextCompat.checkSelfPermission(getApplication(), Manifest.permission.WRITE_EXTERNAL_STORAGE);
                if (hasWriteStoragePermission == PackageManager.PERMISSION_GRANTED) {
                    //拥有权限，执行操作
                    Intent intent = new Intent(Intent.ACTION_PICK, null);
                    intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,"image/jpg");
                    startActivityForResult(intent, 0x1);
                }else{
                    //没有权限，向用户请求权限
                    ActivityCompat.requestPermissions(EditInformationActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                }
            }
        });

        btnUploadPic.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if(EditInformationActivity.this.selectImagePath == null){
                    ToastUtils.showToast(EditInformationActivity.this,"Please select picture to upload!");
                    return;
                }
                ToastUtils.showToast(EditInformationActivity.this,"Uploading!");
                File file = new File(EditInformationActivity.this.selectImagePath);
                OkHttpClient okHttpClient = new OkHttpClient();
                RequestBody image = RequestBody.create(MediaType.parse("image/jpg"), file);
                RequestBody requestBody = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("file", file.getName(), image)
                        .build();
                Request request = new Request.Builder()
                        .url(Api.mainHost + Api.uploadImgPath)
                        .post(requestBody)
                        .build();

                okHttpClient.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {}

                    @Override
                    public void onResponse(Call call, okhttp3.Response response) throws IOException {
                        try {
                            String body = response.body().string();
                            JSONObject retData = new JSONObject(body);
                            if(retData.getBoolean("valid")){
                                String headUrl = retData.getString("url");
                                SPUtil.getInstance().putString("userHead", headUrl);
                                ToastUtils.showToast(EditInformationActivity.this,"Success");
                            }
                        }catch (Exception e){}
                    }
                });
            }
        });


        rbSex.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (group.getCheckedRadioButtonId()) {
                    case R.id.rb_sex_male:
                        SPUtil.getInstance().putString("sex", "male");
                        break;
                    case R.id.rb_sex_female:
                        SPUtil.getInstance().putString("sex", "female");
                        break;
                }
            }
        });

        btnSavePerson.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View view) {
                String sMemberId = SPUtil.getInstance().getString("memberId");
                String sSex = SPUtil.getInstance().getString("sex");
                String sHead = SPUtil.getInstance().getString("userHead");
                String sPhone = rbPhone.getText().toString().trim();
                if(!sPhone.isEmpty())
                    SPUtil.getInstance().putString("phone", sPhone);

                OkGo.<String>post(Api.mainHost+Api.updatePersonUrl)
                        .params("hotelUserId",sMemberId)
                        .params("hotelUserPhone",sPhone)
                        .params("hotelUserGender",sSex)
                        .params("hotelUserImg",sHead)
                        .execute(new StringCallback() {
                            @Override
                            public void onSuccess(Response<String> response) {
                                CodeBean codeBean = JSONUtils.parserObject(response.body(),CodeBean.class);
                                boolean success = codeBean.getSuccess();
                                if(success){
                                    ToastUtils.showToast(EditInformationActivity.this,"Success!");
                                    //Intent intent2 = new Intent(EditInformationActivity.this, MainActivity.class);
                                    //startActivity(intent2);
                                    Intent intent = new Intent();
                                    intent.setAction("refreshInformation");
                                    sendBroadcast(intent);
                                    finish();
                                }else {
                                    ToastUtils.showToast(EditInformationActivity.this,"Save to server error!");
                                }
                            }

                            @Override
                            public void onError(Response<String> response) {
                                super.onError(response);
                            }
                        });
            }
        });

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 1){
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Intent intent = new Intent(Intent.ACTION_PICK, null);
                intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,"image/jpg");
                startActivityForResult(intent, 0x1);
            }else{
            }
        }
    }

    private void showHeadImgFromWeb(String imgUrl){
        OkHttpClient httpClient = new OkHttpClient();
        Request request = new Request.Builder()
                .url(imgUrl)
                .build();
        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {}

            @Override
            public void onResponse(Call call, okhttp3.Response response) throws IOException {
                InputStream inputStream = response.body().byteStream();
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                if(bitmap != null)
                    rbPersonImg.setImageBitmap(bitmap);
            }
        });
    }
}

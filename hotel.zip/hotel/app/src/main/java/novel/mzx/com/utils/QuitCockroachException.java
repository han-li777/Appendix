package novel.mzx.com.utils;

/**
 * Created by Administrator on 2019/7/26 0026.
 */

public final class QuitCockroachException extends RuntimeException {
    public QuitCockroachException(String message) {
        super(message);
    }
}
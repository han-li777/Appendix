package novel.mzx.com.adapter;

import android.content.Context;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.zhy.adapter.recyclerview.CommonAdapter;
import com.zhy.adapter.recyclerview.base.ViewHolder;

import java.util.List;

import novel.mzx.com.R;
import novel.mzx.com.bean.HotelBean;
import novel.mzx.com.constants.Api;


/**
 * Created by Administrator on 2019/4/17 0017.
 */

public class HotelAdapter extends CommonAdapter<HotelBean.Obj> {
    Context mContext;

    public HotelAdapter(Context context, int layoutId, List<HotelBean.Obj> datas) {
        super(context, layoutId, datas);
        mContext = context;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void convert(ViewHolder holder, final HotelBean.Obj s, int position) {


        holder.setText(R.id.news_title,s.getHotelInfoName());
        holder.setText(R.id.tv_address,s.getHotelInfoAddress());
        ImageView news_img = holder.getConvertView().findViewById(R.id.news_img);
        Glide.with(mContext).load(Api.mainImgHost+s.getHotelInfoImg()).into(news_img);

    }


}

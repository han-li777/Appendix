package novel.mzx.com.activity;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;

import com.gyf.immersionbar.ImmersionBar;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.StringCallback;
import com.lzy.okgo.model.Response;

import butterknife.BindView;

import novel.mzx.com.R;
import novel.mzx.com.base.BaseActivity;
import novel.mzx.com.bean.CodeBean;
import novel.mzx.com.constants.Api;
import novel.mzx.com.utils.JSONUtils;
import novel.mzx.com.utils.StringUtils;
import novel.mzx.com.utils.ToastUtils;



public class RegiestActivity extends BaseActivity {

    @BindView(R.id.btn_login)
    Button btn_login;

    @BindView(R.id.et_password)
    EditText etPassword;
    @BindView(R.id.et_admin)
    EditText et_admin;

    @BindView(R.id.iv_back)
    ImageView iv_back;

    @BindView(R.id.et_phone)
    EditText et_phone;

    @BindView(R.id.cb_01)
    CheckBox cb_01;

    @BindView(R.id.cb_02)
    CheckBox cb_02;


    int flag  = 0;

    private String sex="male";


    @Override
    protected int getResourceId() {
        return R.layout.activity_regiest;
    }

    @Override
    protected void initView() {
        super.initView();
        ImmersionBar.with(this).titleBar(R.id.toolbar).keyboardEnable(true).init();
        ImmersionBar.with(RegiestActivity.this).keyboardEnable(false).statusBarDarkFont(true, 0.2f).navigationBarColor(R.color.btn3).init();
        cb_01.setChecked(true);
        cb_02.setChecked(false);
        sex = "male";

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (StringUtils.getEditTextData(et_admin).isEmpty() && StringUtils.getEditTextData(etPassword).isEmpty()){
                    ToastUtils.showToast(RegiestActivity.this,"Please enter a user name or password");
                    return;
                }
                if(StringUtils.getEditTextData(et_admin).isEmpty()){
                    ToastUtils.showToast(RegiestActivity.this,"Please enter one user name");
                    return;
                }

                if(StringUtils.getEditTextData(etPassword).isEmpty()){
                    ToastUtils.showToast(RegiestActivity.this,"Please input a password");
                    return;
                }

                if(StringUtils.getEditTextData(et_phone).isEmpty()){
                    ToastUtils.showToast(RegiestActivity.this,"Please input a phone");
                    return;
                }

                String pwd = StringUtils.getEditTextData(etPassword);
                String admin = StringUtils.getEditTextData(et_admin);
                String phone = StringUtils.getEditTextData(et_phone);

                try {
                    OkGo.<String>post(Api.mainHost+Api.regiestUrl)
                            .params("hotelUserAccount",admin)
                            .params("hotelUserPwd",pwd)
                            .params("hotelUserGender",sex)
                            .params("hotelUserPhone",phone)
                            .execute(new StringCallback() {
                                @Override
                                public void onSuccess(Response<String> response) {
                                    Log.e("Registration",response.body());
                                    CodeBean codeBean = JSONUtils.parserObject(response.body(),CodeBean.class);
                                    boolean success = codeBean.getSuccess();
                                    if(success){
                                        ToastUtils.showToast(RegiestActivity.this,"Registration success!");
                                        finish();
                                    }else {
                                        ToastUtils.showToast(RegiestActivity.this,"Registration failure!");
                                    }


                                }

                                @Override
                                public void onError(Response<String> response) {
                                    super.onError(response);

                                }
                            });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


        cb_01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cb_01.setChecked(true);
                cb_02.setChecked(false);
                flag = 0;
                sex = "male";
            }
        });

        cb_02.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cb_01.setChecked(false);
                cb_02.setChecked(true);
                flag = 1;
                sex = "female";
            }
        });

    }



}

package novel.mzx.com.views;

import android.app.Dialog;
import android.content.Context;
import android.support.annotation.NonNull;

import novel.mzx.com.R;


public class CustomDialog extends Dialog {

    public CustomDialog(@NonNull Context context, int layoutId) {
        super(context, R.style.custom_dialog);
        setContentView(layoutId);
    }
}

package novel.mzx.com.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.StringCallback;
import com.lzy.okgo.model.Response;

import novel.mzx.com.R;
import novel.mzx.com.base.BaseActivity;
import novel.mzx.com.bean.CodeBean;
import novel.mzx.com.constants.Api;
import novel.mzx.com.utils.JSONUtils;
import novel.mzx.com.utils.ToastUtils;

public class CommentActivity extends BaseActivity implements View.OnClickListener{
    private ImageView toolbar_iv_back;
    private TextView tv_score;
    private RatingBar rb_comment;
    private EditText et_content;
    private Button iv_comment_submit;

    @Override
    protected int getResourceId() {
        return R.layout.activity_comment;
    }

    @Override
    protected void initView() {
        super.initView();
        toolbar_iv_back = (ImageView) findViewById(R.id.iv_back);
        iv_comment_submit = (Button) findViewById(R.id.iv_comment_submit);
        toolbar_iv_back.setOnClickListener(this);
        iv_comment_submit.setOnClickListener(this);

        tv_score = (TextView) findViewById(R.id.tv_score);
        rb_comment = (RatingBar) findViewById(R.id.rb_comment);
        et_content = (EditText) findViewById(R.id.et_content);
        rb_comment.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                tv_score.setText(String.valueOf(rating));
            }
        });
    }

    public void onClick(View view){
        switch (view.getId()){
            case R.id.iv_back:
                onBack(view);
                break;
            case R.id.iv_comment_submit:
                String content = et_content.getText().toString();
                if(content == null || content.isEmpty()){
                    ToastUtils.showToast(CommentActivity.this,"Please fill in the evaluation content !");
                    return;
                }
                float score = rb_comment.getRating();

                Intent intent = getIntent();
                String memberId = intent.getStringExtra("memberId");
                String userName = intent.getStringExtra("userName");
                String roomNum = intent.getStringExtra("roomNum");
                OkGo.<String>post(Api.mainHost+Api.commentSubmitUrl)
                        .params("memberId", memberId)
                        .params("userName",userName)
                        .params("roomNum",roomNum)
                        .params("commentScore", score)
                        .params("commentContent",content)
                        .execute(new StringCallback() {
                            @Override
                            public void onSuccess(Response<String> response) {
                                Log.e("Make a comt reservation",response.body());
                                CodeBean codeBean = JSONUtils.parserObject(response.body(),CodeBean.class);
                                boolean success = codeBean.getSuccess();
                                if(success){
                                    ToastUtils.showToast(CommentActivity.this,"Submit comment successfully!");
                                    finish();
                                }else {
                                    ToastUtils.showToast(CommentActivity.this,"Submit comment failed!");
                                }
                            }
                            @Override
                            public void onError(Response<String> response) {
                                super.onError(response);
                            }
                        });
                break;
        }
    }
}

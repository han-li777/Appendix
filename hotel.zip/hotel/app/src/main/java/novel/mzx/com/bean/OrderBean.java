package novel.mzx.com.bean;

import java.util.List;

public class OrderBean {

    private boolean success;

    private String msg;

    private List<Obj> obj ;

    private String attributes;

    private String count;

    public void setSuccess(boolean success){
        this.success = success;
    }
    public boolean getSuccess(){
        return this.success;
    }
    public void setMsg(String msg){
        this.msg = msg;
    }
    public String getMsg(){
        return this.msg;
    }
    public void setObj(List<Obj> obj){
        this.obj = obj;
    }
    public List<Obj> getObj(){
        return this.obj;
    }
    public void setAttributes(String attributes){
        this.attributes = attributes;
    }
    public String getAttributes(){
        return this.attributes;
    }
    public void setCount(String count){
        this.count = count;
    }
    public String getCount(){
        return this.count;
    }


    public class Obj {
        private String hotelMemberRoomId;

        private String hotelMemberRoomUser;

        private String hotelMemberRoomRoomNum;

        private String hotelMemberRoomInfoId;

        private String hotelRoomNum;

        private String hotelRoomPwd;

        private String hotelRoomIsPay;

        private String hotelInfoName;

        private String hotelInfoImg;

        private String hotelInfoAddress;

        private String hotelInfoId;
        private String hotelMemberRoomStartTime;

        private String hotelMemberRoomEndTime;

        private String hotelMemberRoomState;

        private float hotelMemberRoomPrice;

        public void setHotelMemberRoomPrice(float amount){
            this.hotelMemberRoomPrice = amount;
        }
        public float getHotelMemberRoomPrice() { return this.hotelMemberRoomPrice; }

        public void setHotelMemberRoomState(String hotelMemberRoomState){
            this.hotelMemberRoomState = hotelMemberRoomState;
        }
        public String getHotelMemberRoomState(){ return this.hotelMemberRoomState; }

        public void setHotelMemberRoomId(String hotelMemberRoomId){
            this.hotelMemberRoomId = hotelMemberRoomId;
        }
        public String getHotelMemberRoomId(){
            return this.hotelMemberRoomId;
        }
        public void setHotelMemberRoomUser(String hotelMemberRoomUser){
            this.hotelMemberRoomUser = hotelMemberRoomUser;
        }
        public String getHotelMemberRoomUser(){
            return this.hotelMemberRoomUser;
        }
        public void setHotelMemberRoomRoomNum(String hotelMemberRoomRoomNum){
            this.hotelMemberRoomRoomNum = hotelMemberRoomRoomNum;
        }
        public String getHotelMemberRoomRoomNum(){
            return this.hotelMemberRoomRoomNum;
        }
        public void setHotelMemberRoomInfoId(String hotelMemberRoomInfoId){
            this.hotelMemberRoomInfoId = hotelMemberRoomInfoId;
        }
        public String getHotelMemberRoomInfoId(){
            return this.hotelMemberRoomInfoId;
        }
        public void setHotelRoomNum(String hotelRoomNum){
            this.hotelRoomNum = hotelRoomNum;
        }
        public String getHotelRoomNum(){
            return this.hotelRoomNum;
        }
        public void setHotelRoomPwd(String hotelRoomPwd){
            this.hotelRoomPwd = hotelRoomPwd;
        }
        public String getHotelRoomPwd(){
            return this.hotelRoomPwd;
        }
        public void setHotelRoomIsPay(String hotelRoomIsPay){
            this.hotelRoomIsPay = hotelRoomIsPay;
        }
        public String getHotelRoomIsPay(){
            return this.hotelRoomIsPay;
        }
        public void setHotelInfoName(String hotelInfoName){
            this.hotelInfoName = hotelInfoName;
        }
        public String getHotelInfoName(){
            return this.hotelInfoName;
        }
        public void setHotelInfoImg(String hotelInfoImg){
            this.hotelInfoImg = hotelInfoImg;
        }
        public String getHotelInfoImg(){
            return this.hotelInfoImg;
        }
        public void setHotelInfoAddress(String hotelInfoAddress){
            this.hotelInfoAddress = hotelInfoAddress;
        }
        public String getHotelInfoAddress(){
            return this.hotelInfoAddress;
        }
        public void setHotelInfoId(String hotelInfoId){
            this.hotelInfoId = hotelInfoId;
        }
        public String getHotelInfoId(){
            return this.hotelInfoId;
        }

        public String getHotelMemberRoomStartTime() {
            return hotelMemberRoomStartTime;
        }

        public void setHotelMemberRoomStartTime(String hotelMemberRoomStartTime) {
            this.hotelMemberRoomStartTime = hotelMemberRoomStartTime;
        }

        public String getHotelMemberRoomEndTime() {
            return hotelMemberRoomEndTime;
        }

        public void setHotelMemberRoomEndTime(String hotelMemberRoomEndTime) {
            this.hotelMemberRoomEndTime = hotelMemberRoomEndTime;
        }
    }

}

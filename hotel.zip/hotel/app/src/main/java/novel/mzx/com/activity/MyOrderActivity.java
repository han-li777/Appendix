package novel.mzx.com.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.gyf.immersionbar.ImmersionBar;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.StringCallback;
import com.lzy.okgo.model.Response;

import java.util.List;

import butterknife.BindView;
import novel.mzx.com.R;
import novel.mzx.com.adapter.OrderAdapter;
import novel.mzx.com.adapter.RoomAdapter;
import novel.mzx.com.base.BaseActivity;
import novel.mzx.com.bean.OrderBean;
import novel.mzx.com.bean.RoomBean;
import novel.mzx.com.constants.Api;
import novel.mzx.com.utils.JSONUtils;
import novel.mzx.com.utils.SPUtil;

public class MyOrderActivity extends BaseActivity {


    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;

    @BindView(R.id.iv_back)
    ImageView iv_back;


    private LinearLayoutManager mLinearLayoutManager;

    private OrderAdapter roomAdapter;

    @Override
    protected int getResourceId() {
        return R.layout.activity_my_order;
    }

    @Override
    protected void initView() {
        super.initView();
        ImmersionBar.with(this).titleBar(R.id.toolbar).keyboardEnable(true).init();
        ImmersionBar.with(MyOrderActivity.this).keyboardEnable(false).statusBarDarkFont(true, 0.2f).navigationBarColor(R.color.btn3).init();
        mLinearLayoutManager = new LinearLayoutManager(this, LinearLayout.VERTICAL,false);
        recyclerView.setLayoutManager(mLinearLayoutManager);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        registerBoradcastReceiver();

    }


    public void registerBoradcastReceiver() {
        IntentFilter myIntentFilter = new IntentFilter();
        myIntentFilter.addAction("refresh3");
        //注册广播
        registerReceiver(broadcastReceiver, myIntentFilter);
    }


    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            getMyOrderData();
        }
    };


    @Override
    protected void initData() {
        super.initData();
        getMyOrderData();
    }

    private void getMyOrderData() {
        String memberId = SPUtil.getInstance().getString("username");
        OkGo.<String>post(Api.mainHost+Api.reservationHotelListUrl)
                .params("hotelUserAccount",memberId)
                .execute(new StringCallback() {
                    @Override
                    public void onSuccess(Response<String> response) {
                        Log.e("orderList",response.body());
                        OrderBean orderBean = JSONUtils.parserObject(response.body(),OrderBean.class);
                        boolean success = orderBean.getSuccess();
                        if(success){
                            List<OrderBean.Obj> obj = orderBean.getObj();
                            roomAdapter = new OrderAdapter(MyOrderActivity.this,R.layout.item_room_order,obj);
                            recyclerView.setAdapter(roomAdapter);

                        }else {

                        }
                    }

                    @Override
                    public void onError(Response<String> response) {
                        super.onError(response);

                    }
                });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(broadcastReceiver);
    }
}

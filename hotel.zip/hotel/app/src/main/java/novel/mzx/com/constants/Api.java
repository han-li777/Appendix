package novel.mzx.com.constants;

public class Api {
    //public static String mainHost = "http://121.4.44.47:8080";
    //public static String mainImgHost = "http://121.4.44.47:8080/hotel/";
    public static String mainHost = "http://10.0.2.2:8200";
    public static String mainImgHost = "http://10.0.2.2:8200/hotel/";

    //注册
    public static String regiestUrl = "/hotel/registered";

    //登录
    public static String loginUrl = "/hotel/login";

    //酒店列表
    public static String hotelInfoListUrl = "/hotel/hotelInfoList";

    //房间列表
    public static String hotelRoomListUrl = "/hotel/hotelRoomList";

    //预订酒店
    public static String reservationHotelUrl = "/hotel/reservationHotel";

    //预订列表
    public static String reservationHotelListUrl = "/hotel/reservationHotelList";


    //退房
    public static String checkOutRoomUrl = "/hotel/checkOutRoom";

    //更新个人信息
    public static String updatePersonUrl = "/hotel/updatePerson";

    //上传图片
    public static String uploadImgPath = "/hotel/manage/upload";

    //提交评论
    public static String commentSubmitUrl = "/hotel/saveComment";
}

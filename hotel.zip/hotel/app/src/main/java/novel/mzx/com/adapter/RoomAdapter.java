package novel.mzx.com.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.StringCallback;
import com.lzy.okgo.model.Response;
import com.zhy.adapter.recyclerview.CommonAdapter;
import com.zhy.adapter.recyclerview.base.ViewHolder;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import novel.mzx.com.R;
import novel.mzx.com.activity.HotelDeatilsActivity;
import novel.mzx.com.activity.MyOrderActivity;
import novel.mzx.com.bean.CodeBean;
import novel.mzx.com.bean.HotelBean;
import novel.mzx.com.bean.RoomBean;
import novel.mzx.com.constants.Api;
import novel.mzx.com.utils.JSONUtils;
import novel.mzx.com.utils.SPUtil;
import novel.mzx.com.utils.ToastUtils;
import novel.mzx.com.utils.ViewUtils;
import novel.mzx.com.views.CustomDialog;
import novel.mzx.com.utils.MyDateConvert;


/**
 * Created by Administrator on 2019/4/17 0017.
 */

public class RoomAdapter extends CommonAdapter<RoomBean.Obj> {
    Context mContext;

    String hotelId;

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            ViewUtils.cancelLoadingDialog();
            Map<String, String> args = (Map<String, String>) msg.obj;
            String hotelRoomNum = args.get("hotelRoomNum");
            String personMobile = args.get("personMobile");
            String personIdcard = args.get("personIdcard");
            reservationHoteData(hotelId,hotelRoomNum,personMobile,personIdcard);

        }
    };
    public RoomAdapter(Context context, int layoutId, List<RoomBean.Obj> datas, String hotelId) {
        super(context, layoutId, datas);
        mContext = context;
        hotelId = hotelId;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void convert(ViewHolder holder, final RoomBean.Obj s, int position) {


        holder.setText(R.id.news_title,"RoomNumber:"+s.getHotelRoomNum());
        String roomCount = SPUtil.getInstance().getString("roomCount");
        holder.setText(R.id.time_tv,"Number of remaining rooms:"+roomCount);
        holder.setText(R.id.tv_price, "$" + String.valueOf(s.getHotelRoomPrice()));
        int hotelRoomNum = s.getHotelRoomIsPay();
        String username = SPUtil.getInstance().getString("username");
        String booker = s.getHotelRoomBooker();

        holder.setText(R.id.tv_state,"Reservation");
        //holder.setVisible(R.id.lay_reserved, false);
        if(hotelRoomNum == 2){
            holder.setText(R.id.tv_reserved, "Before: " + s.getHotelRoomStart());
            holder.setVisible(R.id.tv_reserved_end, true);
            holder.setText(R.id.tv_reserved_end, "After: " + s.getHotelRoomEnd());
        }else {
            holder.setText(R.id.tv_reserved, "Always available");
            holder.setVisible(R.id.tv_reserved_end, false);
            //holder.setVisible(R.id.tv_label_reserved, false);
        }

        ImageView news_img = holder.getConvertView().findViewById(R.id.news_img);
        Glide.with(mContext).load("https://img.ivsky.com/img/tupian/pre/201107/23/beijing_bandaojiudian-004.jpg").into(news_img);

        holder.setOnClickListener(R.id.tv_state, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = SPUtil.getInstance().getString("username");
                String booker = s.getHotelRoomBooker();

                int days = SPUtil.getInstance().getInt("days",0);
                String start = SPUtil.getInstance().getString("start");
                String end = SPUtil.getInstance().getString("end");
                if(days < 1){
                    ToastUtils.showToast(mContext,"Please choose the check-in time!!");
                    return;
                }
                if(hotelRoomNum == 2) {
                    Date orderStart = MyDateConvert.dotStandStrToDate(start);
                    Date orderEnd = MyDateConvert.dotStandStrToDate(end);
                    Date roomStart = MyDateConvert.dotEnStrToDate(s.getHotelRoomStart());
                    Date roomEnd = MyDateConvert.dotEnStrToDate(s.getHotelRoomEnd());
                    if(roomStart != null && roomEnd != null) {
                        if (orderEnd.after(roomStart) && orderStart.before(roomEnd)) {
                            ToastUtils.showToast(mContext, "Booking time conflict!");
                            return;
                        }
                    }
                }
                showDialog2(s.getHotelRoomNum());

            }
        });
    }

    private void showDialog2(String hotelRoomNum) {

        CustomDialog dialog = new CustomDialog(mContext,R.layout.custom_dialog);
        RelativeLayout rl_sure = dialog.findViewById(R.id.rl_sure);
        RelativeLayout rl_sure1 = dialog.findViewById(R.id.rl_sure1);
        rl_sure1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        rl_sure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText rl_mobile = (EditText) dialog.findViewById(R.id.rl_mobile);
                EditText rl_idcard = (EditText) dialog.findViewById(R.id.rl_idcard);
                String sMobile = rl_mobile.getText().toString().trim();
                String sIdcard = rl_idcard.getText().toString().trim();
                if(sMobile.isEmpty() || sIdcard.isEmpty()){
                    TextView rl_msg = (TextView)dialog.findViewById(R.id.rl_msg);
                     rl_msg.setTextColor(Color.RED);
                     rl_msg.setText("Please input mobile or idcard");
                    return;
                }

                dialog.dismiss();

                ViewUtils.createLoadingDialog2((Activity) mContext,true,"Paying...");
                Message message = new Message();
                Map<String, String> args = new HashMap<String, String>();
                args.put("hotelRoomNum", hotelRoomNum);
                args.put("personMobile", sMobile);
                args.put("personIdcard", sIdcard);
                message.obj = args;
                handler.sendMessageDelayed(message,2000);

            }
        });
        dialog.show();

    }

    private void reservationHoteData(String hotelId, String hotelRoomNum,
                                     String personMobile, String personIdcard) {

        String username = SPUtil.getInstance().getString("username");
        String hotelId2 = SPUtil.getInstance().getString("hotelId");
        int days = SPUtil.getInstance().getInt("days",0);
        String start = SPUtil.getInstance().getString("start");
        String end = SPUtil.getInstance().getString("end");
        if(days < 1){
            ToastUtils.showToast(mContext,"Please choose the check-in time!");
            return;
        }
        OkGo.<String>post(Api.mainHost+Api.reservationHotelUrl)
                .params("hotelUserAccount",username)
                .params("hotelInfoId",hotelId2)
                .params("hotelRoomNum",hotelRoomNum)
                .params("startTime",start)
                .params("endTime",end)
                .params("personMobile", personMobile)
                .params("personIdcard", personIdcard)
                .execute(new StringCallback() {
                    @Override
                    public void onSuccess(Response<String> response) {
                        Log.e("Make a room reservation",response.body());
                        CodeBean codeBean = JSONUtils.parserObject(response.body(),CodeBean.class);
                        boolean success = codeBean.getSuccess();
                        if(success){

                            ToastUtils.showToast(mContext,"Payment successful!");
                            Intent intent = new Intent();
                            intent.setAction("refresh2");
                            mContext.sendBroadcast(intent);

                            Intent payJump = new Intent(mContext, MyOrderActivity.class);
                            mContext.startActivity(payJump);
                        }else {

                        }
                    }

                    @Override
                    public void onError(Response<String> response) {
                        super.onError(response);

                    }
                });

    }

    private void showDialog1(String hotelRoomNum) {

        CustomDialog dialog = new CustomDialog(mContext,R.layout.custom_dialog_pwd);
        TextView tv_01 = dialog.findViewById(R.id.tv_01);
        RelativeLayout rl_sure = dialog.findViewById(R.id.rl_sure);
        tv_01.setText(hotelRoomNum);
        rl_sure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();


    }


}

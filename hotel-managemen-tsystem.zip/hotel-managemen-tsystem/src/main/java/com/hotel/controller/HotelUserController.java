package com.hotel.controller;

import com.hotel.entity.HotelUser;
import com.hotel.mapper.HotelUserMapper;
import com.hotel.utils.AjaxJson;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @ClassName: HotelUserController
 * @program: hotel-managemen-tsystem
 **/
@RestController
@Api(tags = "用户模块")
public class HotelUserController {


    @Autowired
    private HotelUserMapper userMapper;

    @ApiOperation(value = "登录", httpMethod = "POST", notes = "加载数据", response = AjaxJson.class)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "hotelUserAccount", value = "账号", paramType = "query", dataType = "String"),
            @ApiImplicitParam(name = "hotelUserPwd", value = "密码", paramType = "query", dataType = "String")
    })
    @RequestMapping("/login")
    public AjaxJson login(String hotelUserAccount,String hotelUserPwd){
        AjaxJson json = new AjaxJson();
        if(StringUtils.isEmpty(hotelUserAccount)){
            json.setSuccess(false);
            json.setMsg("账号不能为空");
        }
        if(StringUtils.isEmpty(hotelUserPwd)){
            json.setSuccess(false);
            json.setMsg("密码不能为空");
        }
        HotelUser user = userMapper.getUserByhotelUserAccount(hotelUserAccount);
        String pwdDb = user.getHotelUserPwd().trim();
        if(!hotelUserPwd.trim().equals(pwdDb)){
            json.setSuccess(false);
            json.setMsg("用户名或账号错误");
            return json;
        }
        json.setObj(user);
        return json;
    }


    @ApiOperation(value = "注册", httpMethod = "POST", notes = "加载数据", response = AjaxJson.class)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "hotelUserAccount", value = "账号", paramType = "query", dataType = "String"),
            @ApiImplicitParam(name = "hotelUserPwd", value = "密码", paramType = "query", dataType = "String"),
            @ApiImplicitParam(name = "hotelUserName", value = "姓名", paramType = "query", dataType = "String"),
            @ApiImplicitParam(name = "hotelUserGender", value = "性别", paramType = "query", dataType = "String"),
            @ApiImplicitParam(name = "hotelUserPhone", value = "手机号", paramType = "query", dataType = "String")
    })
    @RequestMapping("/registered")
    public AjaxJson registered(String hotelUserAccount,String hotelUserPwd,String hotelUserName,String hotelUserGender,String hotelUserPhone){
        AjaxJson json = new AjaxJson();
        HotelUser userInfo = userMapper.getUserByhotelUserAccount(hotelUserAccount);
        if(null != userInfo){
            json.setSuccess(false);
            json.setMsg("账号已存在");
            return json;
        }
        HotelUser user = new HotelUser();
        user.setHotelUserAccount(hotelUserAccount.trim());
        user.setHotelUserPwd(hotelUserPwd.trim());
        user.setHotelUserGender(hotelUserGender);
        user.setHotelUserName(hotelUserName);
        user.setHotelUserPhone(hotelUserPhone);
        userMapper.insertSelective(user);
        json.setObj(user);
        return json;
    }


}

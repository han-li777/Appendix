package com.hotel.controller;

import java.util.*;
import com.hotel.entity.HotelInfo;
import com.hotel.mapper.HotelInfoMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import com.hotel.utils.ManageAjaxResult;

@Controller
@RequestMapping("/manage/hotelinfo")
public class ManageHotelController {
    @Autowired
    private HotelInfoMapper hotelMapper;

    @RequestMapping("/list")
    public String HotelInfoList(HttpServletRequest request, Model model)
    {
        String hotelName = request.getParameter("hotelname");
        List<HotelInfo> list = hotelMapper.getAllList(hotelName);
        model.addAttribute("dataList", list);
        model.addAttribute("total", list.size());
        model.addAttribute("preSearch", hotelName);
        return "hotelinfo/hotel_list";
    }

    @RequestMapping(value="/add", method= RequestMethod.GET)
    public String HotelInfoAdd(Model model)
    {
        return "hotelinfo/hotel_add";
    }

    @RequestMapping(value="/addSave", method= RequestMethod.POST)
    public @ResponseBody
    ManageAjaxResult HotelInfoAddSave(HotelInfo hotel)
    {
        ManageAjaxResult result = new ManageAjaxResult();
        result.setValid(true);
        result.setMsg("success");
        int ret = hotelMapper.insertSelective(hotel);
        if(ret <= 0) {
            result.setValid(false);
            result.setMsg("save error");
        }
        return result;
    }

    @RequestMapping(value="/edit", method= RequestMethod.GET)
    public String HotelInfoEdit(@RequestParam(value="hid", required = true) int hid, Model model)
    {
        HotelInfo hotel = hotelMapper.selectByPrimaryKey(hid);
        model.addAttribute("hotel", hotel);
        return "hotelinfo/hotel_edit";
    }

    @RequestMapping(value="/editSave", method= RequestMethod.POST)
    public @ResponseBody
    ManageAjaxResult HotelInfoEditSave(HotelInfo hotel)
    {
        ManageAjaxResult result = new ManageAjaxResult();
        result.setValid(true);
        result.setMsg("success");
        int ret = hotelMapper.updateByPrimaryKeySelective(hotel);
        if(ret <= 0) {
            result.setValid(false);
            result.setMsg("update error");
        }
        return result;
    }

    @RequestMapping(value="/delete", method= RequestMethod.GET)
    public @ResponseBody
    ManageAjaxResult HotelInfoDelete(@RequestParam(value="hid", required = true) int hid)
    {
        ManageAjaxResult result = new ManageAjaxResult();
        result.setValid(true);
        result.setMsg("success");
        int ret = hotelMapper.deleteByPrimaryKey(hid);
        if(ret <= 0) {
            result.setValid(false);
            result.setMsg("update error");
        }
        return result;
    }
}
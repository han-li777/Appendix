package com.hotel.controller;

import java.util.*;
import com.hotel.entity.HotelUser;
import com.hotel.mapper.HotelUserMapper;
import com.hotel.utils.AjaxJson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import javax.servlet.http.HttpServletRequest;
import com.hotel.utils.ManageAjaxResult;

@Controller
@RequestMapping("/manage/hoteluser")
public class ManageUserController {
    @Autowired
    private HotelUserMapper userMapper;

    @RequestMapping("/list")
    public String HotelUserList(HttpServletRequest request, Model model)
    {
        String userName = request.getParameter("username");
        List<HotelUser> list = userMapper.getAllList(userName);
        model.addAttribute("dataList", list);
        model.addAttribute("total", list.size());
        model.addAttribute("preSearch", userName);
        return "hoteluser/user_list";
    }

    @RequestMapping(value="/add", method= RequestMethod.GET)
    public String HotelUserAdd(Model model)
    {
        return "hoteluser/user_add";
    }

    @RequestMapping(value="/addSave", method= RequestMethod.POST)
    public @ResponseBody
    ManageAjaxResult HotelUserAddSave(HotelUser user)
    {
        ManageAjaxResult result = new ManageAjaxResult();
        result.setValid(true);
        result.setMsg("success");
        int ret = userMapper.insertSelective(user);
        if(ret <= 0) {
            result.setValid(false);
            result.setMsg("save error");
        }
        return result;
    }

    @RequestMapping(value="/edit", method= RequestMethod.GET)
    public String HotelUserEdit(@RequestParam(value="uid", required = true) int uid, Model model)
    {
        HotelUser user = userMapper.selectByPrimaryKey(uid);
        model.addAttribute("user", user);
        return "hoteluser/user_edit";
    }

    @RequestMapping(value="/editSave", method= RequestMethod.POST)
    public @ResponseBody
    ManageAjaxResult HotelUserEditSave(HotelUser user)
    {
        ManageAjaxResult result = new ManageAjaxResult();
        result.setValid(true);
        result.setMsg("success");
        int ret = userMapper.updateByPrimaryKeySelective(user);
        if(ret <= 0) {
            result.setValid(false);
            result.setMsg("update error");
        }
        return result;
    }

    @RequestMapping(value="/delete", method= RequestMethod.GET)
    public @ResponseBody
    ManageAjaxResult HotelUserDelete(@RequestParam(value="uid", required = true) int uid)
    {
        ManageAjaxResult result = new ManageAjaxResult();
        result.setValid(true);
        result.setMsg("success");
        int ret = userMapper.deleteByPrimaryKey(uid);
        if(ret <= 0) {
            result.setValid(false);
            result.setMsg("update error");
        }
        return result;
    }
}
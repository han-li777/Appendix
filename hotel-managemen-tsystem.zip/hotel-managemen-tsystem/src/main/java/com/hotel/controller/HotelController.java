package com.hotel.controller;

import com.hotel.entity.*;
import com.hotel.mapper.*;
import com.hotel.utils.AjaxJson;
import com.hotel.utils.MyDateConvert;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * @ClassName: HotelController
 * @program: hotel-managemen-tsystem
 **/
@RestController
@Api(tags = "酒店模块")
public class HotelController {

    @Autowired
    private HotelInfoMapper hotelMapper;
    @Autowired
    private HotelRoomMapper roomMapper;
    @Autowired
    private HotelMemberRoomMapper memberRoomMapper;
    @Autowired
    private HotelUserMapper userMapper;
    @Autowired
    private HotelCommentMapper commentMapper;

    @ApiOperation(value = "根据酒店查询房间列表", httpMethod = "POST", notes = "加载数据", response = AjaxJson.class)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "hotelRoomInfoId", value = "酒店主键id", paramType = "query", dataType = "int")
    })
    @RequestMapping("/hotelRoomList")
    public AjaxJson hotelRoomList(Integer hotelRoomInfoId){
        AjaxJson json = new AjaxJson();
        List<HotelRoom> list = roomMapper.getRoomListByHotelRoomInfoId(hotelRoomInfoId);
        for(HotelRoom item : list)
        {
            if(item.getHotelRoomIsPay() == 2) {
                item.setHotelRoomStart(MyDateConvert.dotStrToEn(item.getHotelRoomStart()));
                item.setHotelRoomEnd(MyDateConvert.dotStrToEn(item.getHotelRoomEnd()));
            }else{
                item.setHotelRoomStart("");
                item.setHotelRoomEnd("");
            }
        }
        int count = hotelMapper.getRoomEmptyCount(hotelRoomInfoId);
        json.setCount(count);
        json.setObj(list);
        return json;
    }


    @ApiOperation(value = "酒店列表", httpMethod = "POST", notes = "加载数据", response = AjaxJson.class)
    @RequestMapping("/hotelInfoList")
    public AjaxJson hotelInfoList(){
        AjaxJson json = new AjaxJson();
        List<HotelInfo> list = hotelMapper.getRoomListByHotelRoomInfoId();
        json.setObj(list);
        return json;
    }

    @ApiOperation(value = "预定列表", httpMethod = "POST", notes = "加载数据", response = AjaxJson.class)
    @RequestMapping("/reservationHotelList")
    public AjaxJson reservationHotelList(String hotelUserAccount){
        AjaxJson json = new AjaxJson();
        List<HotelMemberRoom> list = memberRoomMapper.findHotelMemberRoomInfo(hotelUserAccount);
        for(HotelMemberRoom item : list)
        {
            item.setHotelMemberRoomStartTime(MyDateConvert.dotStrToEn(item.getHotelMemberRoomStartTime()));
            item.setHotelMemberRoomEndTime(MyDateConvert.dotStrToEn(item.getHotelMemberRoomEndTime()));
        }
        json.setObj(list);
        return json;
    }


    @ApiOperation(value = "预定酒店", httpMethod = "POST", notes = "加载数据", response = AjaxJson.class)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "hotelUserAccount", value = "用户账号", paramType = "query", dataType = "string"),
            @ApiImplicitParam(name = "hotelRoomNum", value = "房间号", paramType = "query", dataType = "string"),
            @ApiImplicitParam(name = "hotelInfoId", value = "酒店id", paramType = "query", dataType = "int"),
            @ApiImplicitParam(name = "startTime", value = "开始时间", paramType = "query", dataType = "string"),
            @ApiImplicitParam(name = "endTime", value = "结束时间", paramType = "query", dataType = "string"),
            @ApiImplicitParam(name = "personMobile", value = "联系方式", paramType = "query", dataType = "string"),
            @ApiImplicitParam(name = "personIdcard", value = "身份证号", paramType = "query", dataType = "string")
    })
    @RequestMapping("/reservationHotel")
    public AjaxJson reservationHotel(String hotelUserAccount,String hotelRoomNum,Integer hotelInfoId,
                                     String startTime,String endTime,String personMobile,String personIdcard){
        AjaxJson json = null;
        try {
            json = new AjaxJson();

            HotelRoom infoRoom = roomMapper.selectByPrimaryKey(hotelInfoId);
            if(infoRoom.getHotelRoomIsPay() == 2){
                Date roomStart = MyDateConvert.dotStrToDate(infoRoom.getHotelRoomStart());
                Date roomEnd = MyDateConvert.dotStrToDate(infoRoom.getHotelRoomEnd());
                Date orderStart = MyDateConvert.dotStrToDate(startTime);
                Date orderEnd = MyDateConvert.dotStrToDate(endTime);
                if(orderEnd.after(roomStart) && orderStart.before(roomEnd)){
                    json.setSuccess(false);
                    json.setMsg("Booking time conflict!!");
                    return json;
                }
            }

            HotelMemberRoom hotelMemberRoom = new HotelMemberRoom();
            hotelMemberRoom.setHotelMemberRoomUser(hotelUserAccount);
            hotelMemberRoom.setHotelMemberRoomRoomNum(hotelRoomNum);
            hotelMemberRoom.setHotelMemberRoomInfoId(hotelInfoId);
            hotelMemberRoom.setHotelMemberRoomStartTime(startTime);
            hotelMemberRoom.setHotelMemberRoomEndTime(endTime);
            hotelMemberRoom.setHotelMemberRoomState("1");
            hotelMemberRoom.setHotelMemberRoomPrice(infoRoom.getHotelRoomPrice());
            hotelMemberRoom.setHotelMemberRoomMobile(personMobile);
            hotelMemberRoom.setHotelMemberRoomIdcard(personIdcard);
            memberRoomMapper.insert(hotelMemberRoom);

            HotelRoom hotelRoom  = new HotelRoom();
            hotelRoom.setHotelRoomNum(hotelRoomNum);
            hotelRoom.setHotelRoomInfoId(hotelInfoId);
            /*hotelRoom.setHotelRoomIsPay(2);
            hotelRoom.setHotelRoomStart(startTime);
            hotelRoom.setHotelRoomEnd(endTime);
            hotelRoom.setHotelRoomBooker(hotelUserAccount);*/
            updateHotelRoom(hotelRoom);
            roomMapper.updateByRoomNum(hotelRoom);
        } catch (Exception e) {
            e.printStackTrace();
            json.setSuccess(false);
            json.setMsg("操所失败");
        }
        return json;
    }

    @ApiOperation(value = "退房间", httpMethod = "POST", notes = "加载数据", response = AjaxJson.class)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "memberId", value = "订单ID", paramType = "query", dataType = "int"),
            @ApiImplicitParam(name = "hotelUserAccount", value = "用户账号", paramType = "query", dataType = "string"),
            @ApiImplicitParam(name = "hotelRoomNum", value = "房间号", paramType = "query", dataType = "string"),
            @ApiImplicitParam(name = "hotelInfoId", value = "酒店id", paramType = "query", dataType = "int")
    })
    @RequestMapping("/checkOutRoom")
    public AjaxJson checkOutRoom(Integer memberId, String hotelUserAccount,String hotelRoomNum,Integer hotelInfoId){
        AjaxJson json = new AjaxJson();
        SimpleDateFormat sdp = new SimpleDateFormat("yyyy.MM.dd");
        String strEndTime = sdp.format(new Date());
        HotelMemberRoom hotelMemberRoom = new HotelMemberRoom();
        hotelMemberRoom.setHotelMemberRoomId(memberId);
        hotelMemberRoom.setHotelMemberRoomUser(hotelUserAccount);
        hotelMemberRoom.setHotelMemberRoomRoomNum(hotelRoomNum);
        hotelMemberRoom.setHotelMemberRoomInfoId(hotelInfoId);
        hotelMemberRoom.setHotelMemberRoomEndTime(strEndTime);
        hotelMemberRoom.setHotelMemberRoomState("2");
        //memberRoomMapper.updateByPrimaryKeySelective(hotelMemberRoom);
        memberRoomMapper.updateByPrimaryKeySelective(hotelMemberRoom);

        HotelRoom hotelRoom  = new HotelRoom();
        hotelRoom.setHotelRoomNum(hotelRoomNum);
        hotelRoom.setHotelRoomInfoId(hotelInfoId);
        /*hotelRoom.setHotelRoomIsPay(1);*/
        updateHotelRoom(hotelRoom);
        roomMapper.updateByRoomNum(hotelRoom);

        return json;
    }

    @ApiOperation(value = "更新用户信息", httpMethod = "POST", notes = "更新数据", response = AjaxJson.class)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "hotelUserId", value = "用户主键id", paramType = "query", dataType = "int"),
            @ApiImplicitParam(name = "hotelUserPhone", value = "手机号", paramType = "query", dataType = "string"),
            @ApiImplicitParam(name = "hotelUserGender", value = "性别", paramType = "query", dataType = "string"),
            @ApiImplicitParam(name = "hotelUserImg", value = "头像", paramType = "query", dataType = "string")
    })
    @RequestMapping("/updatePerson")
    public AjaxJson updatePersonInformation(Integer hotelUserId, String hotelUserPhone,
                                  String hotelUserGender, String hotelUserImg){
        AjaxJson json = new AjaxJson();
        HotelUser user = new HotelUser();
        user.setHotelUserId(hotelUserId);
        user.setHotelUserPhone(hotelUserPhone);
        user.setHotelUserGender(hotelUserGender);
        user.setHotelUserImg(hotelUserImg);
        userMapper.updateByPrimaryKeySelective(user);
        return json;
    }

    @ApiOperation(value = "保存评价信息", httpMethod = "POST", notes = "评价信息", response = AjaxJson.class)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "memberId", value = "订单id", paramType = "query", dataType = "int"),
            @ApiImplicitParam(name = "userName", value = "用户名", paramType = "query", dataType = "string"),
            @ApiImplicitParam(name = "roomNum", value = "房间号", paramType = "query", dataType = "string"),
            @ApiImplicitParam(name = "commentScore", value = "评分", paramType = "query", dataType = "float"),
            @ApiImplicitParam(name = "commentContent", value = "评价内容", paramType = "query", dataType = "string")
    })
    @RequestMapping("/saveComment")
    public AjaxJson saveRoomComment(Integer memberId, String userName, String roomNum,
                                    Float commentScore, String commentContent){
        AjaxJson json = new AjaxJson();
        SimpleDateFormat df = new SimpleDateFormat("dd MMM,yyyy", Locale.UK);
        String nowStr = df.format(new Date());
        HotelComment comment = new HotelComment();
        comment.setHotelCommentMemberId(memberId);
        comment.setHotelCommentUser(userName);
        comment.setHotelCommentRoomNum(roomNum);
        comment.setHotelCommentScore(commentScore);
        comment.setHotelCommentContent(commentContent);
        comment.setHotelCommentTime(nowStr);
        commentMapper.insert(comment);
        return json;
    }

    private boolean updateHotelRoom(HotelRoom hotelRoom)
    {
        List<HotelMemberRoom> usingBookings = memberRoomMapper.getRoomInUseBookings(hotelRoom.getHotelRoomNum());
        if(usingBookings.size() <= 0)
        {
            hotelRoom.setHotelRoomIsPay(1);
            hotelRoom.setHotelRoomStart("");
            hotelRoom.setHotelRoomEnd("");
            return false;
        }
        Date start = null;
        Date end = null;
        for(HotelMemberRoom item : usingBookings)
        {
            Date itemStart = MyDateConvert.dotStrToDate(item.getHotelMemberRoomStartTime());
            Date itemEnd = MyDateConvert.dotStrToDate(item.getHotelMemberRoomEndTime());
            if(start == null){
                start = itemStart;
            }else{
                if(itemStart.before(start))
                    start = itemStart;
            }
            if(end == null){
                end = itemEnd;
            }else{
                if(itemEnd.after(end))
                    end = itemEnd;
            }
        }
        hotelRoom.setHotelRoomIsPay(2);
        hotelRoom.setHotelRoomStart(MyDateConvert.dateToDotStr(start));
        hotelRoom.setHotelRoomEnd(MyDateConvert.dateToDotStr(end));
        return true;
    }
}

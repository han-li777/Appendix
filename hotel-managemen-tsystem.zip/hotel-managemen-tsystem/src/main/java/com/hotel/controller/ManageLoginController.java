package com.hotel.controller;

import java.util.*;
import com.hotel.entity.ManageAccount;
import com.hotel.mapper.ManageAccountMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import javax.servlet.http.HttpServletRequest;
import com.hotel.utils.ManageAjaxResult;

@Controller
@RequestMapping("/manage")
public class ManageLoginController {
    @Autowired
    private ManageAccountMapper accountMapper;

    @RequestMapping("/main")
    public String MainManage()
    {
        return "main";
    }

    @RequestMapping(value="/login", method= RequestMethod.GET)
    public String ManageLoginView(Model model)
    {
        return "login";
    }

    @RequestMapping("/checkLogin")
    public @ResponseBody
    ManageAjaxResult ManageCheckLogin(HttpServletRequest request,
                                  @RequestParam String account, @RequestParam String password)
    {
        ManageAccount manager = new ManageAccount();
        manager.setManagerAccount(account);
        manager.setManagerPassword(password);
        int ret = accountMapper.checkManageLogin(manager);

        ManageAjaxResult result = new ManageAjaxResult();
        result.setValid(false);
        result.setMsg("login failed");
        if(ret > 0) {
            result.setValid(true);
            result.setMsg("success");
            request.getSession().setAttribute("manager", account);
        }
        return result;
    }

    @RequestMapping("/logout")
    public String ManageLogout(HttpServletRequest request)
    {
        request.getSession().removeAttribute("manager");
        return "redirect:/manage/main";
    }
}
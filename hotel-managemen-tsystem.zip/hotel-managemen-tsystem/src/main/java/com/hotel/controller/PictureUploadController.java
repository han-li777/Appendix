package com.hotel.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import com.hotel.utils.UploadResult;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;

@Controller
public class PictureUploadController {
    @RequestMapping(value = "/manage/upload", method = RequestMethod.POST)
    public @ResponseBody
    UploadResult upload(@RequestParam("file") MultipartFile files) throws IOException {
        UploadResult result = new UploadResult();
        result.setValid(true);
        result.setMsg("success");
        try{
            String name = files.getOriginalFilename();
            String time = String.valueOf(System.currentTimeMillis());
            String newName = time + ".jpg";
            String path = Thread.currentThread().getContextClassLoader().getResource("").getPath()
                    + "static";
            File file1 = new File(path);
            if(!file1.exists())
                file1.mkdir();
            path += File.separator + "img";
            File file2 = new File(path);
            if(!file2.exists())
                file2.mkdir();
            path = path + File.separator + newName;
            System.out.println(path);
            File uploadFile = new File(path);
            files.transferTo(uploadFile);
            result.setUrl("/img/" + newName);
        }catch(IOException e){
            result.setValid(false);
            result.setMsg(e.getMessage());
        }
        return result;
    }
}

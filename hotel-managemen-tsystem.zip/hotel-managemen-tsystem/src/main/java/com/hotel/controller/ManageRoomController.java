package com.hotel.controller;

import java.util.*;

import com.hotel.entity.HotelComment;
import com.hotel.entity.HotelMemberRoom;
import com.hotel.entity.HotelRoom;
import com.hotel.mapper.HotelCommentMapper;
import com.hotel.mapper.HotelMemberRoomMapper;
import com.hotel.mapper.HotelRoomMapper;
import com.hotel.utils.MyDateConvert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import com.hotel.utils.ManageAjaxResult;

@Controller
@RequestMapping("/manage/hotelroom")
public class ManageRoomController {
    @Autowired
    private HotelRoomMapper roomMapper;
    @Autowired
    private HotelMemberRoomMapper memberRoomMapper;
    @Autowired
    private HotelCommentMapper commentMapper;

    @RequestMapping("/list")
    public String HotelRoomList(@RequestParam(value="hotelid", required = true) int hotelId,
                                HttpServletRequest request, Model model)
    {
        String roomNum = request.getParameter("roomnum");
        List<HotelRoom> list = roomMapper.getAllList(hotelId, roomNum);
        for(HotelRoom item : list)
        {
            if(item.getHotelRoomIsPay() == 2) {
                item.setHotelRoomStart(MyDateConvert.dotStrToEn(item.getHotelRoomStart()));
                item.setHotelRoomEnd(MyDateConvert.dotStrToEn(item.getHotelRoomEnd()));
            }else{
                item.setHotelRoomStart("--");
                item.setHotelRoomEnd("--");
                item.setHotelRoomBooker("");
            }
        }
        model.addAttribute("dataList", list);
        model.addAttribute("total", list.size());
        model.addAttribute("preSearch", roomNum);
        model.addAttribute("hotelId", hotelId);
        return "hotelroom/room_list";
    }

    @RequestMapping(value="/add", method= RequestMethod.GET)
    public String HotelRoomAdd(@RequestParam(value="hotelid", required = true) int hotelId, Model model)
    {
        model.addAttribute("hotelId", hotelId);
        return "hotelroom/room_add";
    }

    @RequestMapping(value="/addSave", method= RequestMethod.POST)
    public @ResponseBody
    ManageAjaxResult HotelRoomAddSave(HotelRoom room)
    {
        ManageAjaxResult result = new ManageAjaxResult();
        result.setValid(true);
        result.setMsg("success");
        int ret = roomMapper.insertSelective(room);
        if(ret <= 0) {
            result.setValid(false);
            result.setMsg("save error");
        }
        return result;
    }

    @RequestMapping(value="/edit", method= RequestMethod.GET)
    public String HotelRoomEdit(@RequestParam(value="hid", required = true) int hid, Model model)
    {
        HotelRoom room = roomMapper.selectByPrimaryKey(hid);
        model.addAttribute("room", room);
        return "hotelroom/room_edit";
    }

    @RequestMapping(value="/editSave", method= RequestMethod.POST)
    public @ResponseBody
    ManageAjaxResult HotelRoomEditSave(HotelRoom room)
    {
        ManageAjaxResult result = new ManageAjaxResult();
        result.setValid(true);
        result.setMsg("success");
        int ret = roomMapper.updateByPrimaryKeySelective(room);
        if(ret <= 0) {
            result.setValid(false);
            result.setMsg("update error");
        }
        return result;
    }

    @RequestMapping(value = "/booking", method = RequestMethod.GET)
    public String HotelRoomBooking(@RequestParam(value="num", required = true) String roomNum, Model model)
    {
        List<HotelMemberRoom> roomBookings = GetRoomBookings(roomNum);
        List<HotelMemberRoom> usingBookings = new ArrayList<HotelMemberRoom>();
        List<HotelMemberRoom> endBookings = new ArrayList<HotelMemberRoom>();
        for(HotelMemberRoom item : roomBookings)
        {
            item.setHotelMemberRoomStartTime(MyDateConvert.dotStrToEn(item.getHotelMemberRoomStartTime()));
            item.setHotelMemberRoomEndTime(MyDateConvert.dotStrToEn(item.getHotelMemberRoomEndTime()));
            if(item.getHotelMemberRoomState().equals("1")) {
                usingBookings.add(item);
            }else{
                endBookings.add(item);
            }
        }
        model.addAttribute("usingBookingList", usingBookings);
        model.addAttribute("endBookingList", endBookings);
        return "hotelroom/room_booking";
    }

    @RequestMapping(value = "/comments", method = RequestMethod.GET)
    public String HotelRoomComments(@RequestParam(value="num", required = true) String roomNum, Model model)
    {
        List<HotelComment> comments = commentMapper.getCommentListByRoomNum(roomNum);
        model.addAttribute("commentList", comments);
        return "hotelroom/room_comment";
    }

    @RequestMapping(value="/delete", method= RequestMethod.GET)
    public @ResponseBody
    ManageAjaxResult HotelRoomDelete(@RequestParam(value="hid", required = true) int hid)
    {
        ManageAjaxResult result = new ManageAjaxResult();
        result.setValid(true);
        result.setMsg("success");
        int ret = roomMapper.deleteByPrimaryKey(hid);
        if(ret <= 0) {
            result.setValid(false);
            result.setMsg("update error");
        }
        return result;
    }

    private List<HotelMemberRoom> GetRoomBookings(String roomNum)
    {
        return memberRoomMapper.getRoomBookings(roomNum);
    }
}
package com.hotel.controller;

import java.util.*;
import com.hotel.entity.HotelMemberRoom;
import com.hotel.mapper.HotelMemberRoomMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import com.hotel.utils.ManageAjaxResult;

@Controller
@RequestMapping("/manage/hotelmember")
public class ManageMemberController {
    @Autowired
    private HotelMemberRoomMapper memberMapper;

    @RequestMapping("/list")
    public String HotelMemberList(HttpServletRequest request, Model model)
    {
        String memberName = request.getParameter("membername");
        List<HotelMemberRoom> list = memberMapper.getAllList(memberName);
        model.addAttribute("dataList", list);
        model.addAttribute("total", list.size());
        model.addAttribute("preSearch", memberName);
        return "hotelmember/member_list";
    }

    @RequestMapping(value="/edit", method= RequestMethod.GET)
    public String HotelMemberEdit(@RequestParam(value="mid", required = true) int mid, Model model)
    {
        HotelMemberRoom member = memberMapper.selectByPrimaryKey(mid);
        model.addAttribute("member", member);
        return "hotelmember/member_edit";
    }

    @RequestMapping(value="/editSave", method= RequestMethod.POST)
    public @ResponseBody
    ManageAjaxResult HotelMemberEditSave(HotelMemberRoom member)
    {
        ManageAjaxResult result = new ManageAjaxResult();
        result.setValid(true);
        result.setMsg("success");
        int ret = memberMapper.updateByPrimaryKeySelective(member);
        if(ret <= 0) {
            result.setValid(false);
            result.setMsg("update error");
        }
        return result;
    }

    @RequestMapping(value="/delete", method= RequestMethod.GET)
    public @ResponseBody
    ManageAjaxResult HotelMemberDelete(@RequestParam(value="mid", required = true) int mid)
    {
        ManageAjaxResult result = new ManageAjaxResult();
        result.setValid(true);
        result.setMsg("success");
        int ret = memberMapper.deleteByPrimaryKey(mid);
        if(ret <= 0) {
            result.setValid(false);
            result.setMsg("update error");
        }
        return result;
    }
}
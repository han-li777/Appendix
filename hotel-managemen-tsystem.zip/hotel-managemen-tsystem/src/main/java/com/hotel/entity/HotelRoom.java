package com.hotel.entity;

public class HotelRoom {
    private Integer hotelRoomId;

    private String hotelRoomNum;

    private String hotelRoomPwd;

    private Integer hotelRoomIsPay;

    private Integer hotelRoomInfoId;

    private String hotelRoomStart;
    private String hotelRoomEnd;

    private Float hotelRoomPrice;
    private String hotelRoomBooker;

    public String getHotelRoomBooker() { return hotelRoomBooker; }
    public void setHotelRoomBooker(String booker) { this.hotelRoomBooker = booker; }

    public String getHotelRoomStart() { return hotelRoomStart; }
    public void setHotelRoomStart(String hotelRoomStart) { this.hotelRoomStart = hotelRoomStart; }

    public Float getHotelRoomPrice() { return hotelRoomPrice; }
    public void setHotelRoomPrice(Float hotelRoomPrice) { this.hotelRoomPrice = hotelRoomPrice; }

    public String getHotelRoomEnd() { return hotelRoomEnd; }
    public void setHotelRoomEnd(String hotelRoomEnd) { this.hotelRoomEnd = hotelRoomEnd; }

    public Integer getHotelRoomId() {
        return hotelRoomId;
    }

    public void setHotelRoomId(Integer hotelRoomId) {
        this.hotelRoomId = hotelRoomId;
    }

    public String getHotelRoomNum() {
        return hotelRoomNum;
    }

    public void setHotelRoomNum(String hotelRoomNum) {
        this.hotelRoomNum = hotelRoomNum == null ? null : hotelRoomNum.trim();
    }

    public String getHotelRoomPwd() {
        return hotelRoomPwd;
    }

    public void setHotelRoomPwd(String hotelRoomPwd) {
        this.hotelRoomPwd = hotelRoomPwd == null ? null : hotelRoomPwd.trim();
    }

    public Integer getHotelRoomIsPay() {
        return hotelRoomIsPay;
    }

    public void setHotelRoomIsPay(Integer hotelRoomIsPay) {
        this.hotelRoomIsPay = hotelRoomIsPay;
    }

    public Integer getHotelRoomInfoId() {
        return hotelRoomInfoId;
    }

    public void setHotelRoomInfoId(Integer hotelRoomInfoId) {
        this.hotelRoomInfoId = hotelRoomInfoId;
    }
}
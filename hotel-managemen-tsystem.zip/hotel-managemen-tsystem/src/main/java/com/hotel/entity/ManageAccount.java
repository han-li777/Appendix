package com.hotel.entity;

public class ManageAccount {
    private Integer managerId;
    private String managerAccount;
    private String managerPassword;

    public Integer getManagerId() { return managerId; }

    public void setManagerId(Integer managerId) { this.managerId = managerId; }

    public String getManagerAccount() { return managerAccount; }

    public void setManagerAccount(String managerAccount) { this.managerAccount = managerAccount; }

    public String getManagerPassword() { return managerPassword; }

    public void setManagerPassword(String managerPassword) { this.managerPassword = managerPassword; }
}

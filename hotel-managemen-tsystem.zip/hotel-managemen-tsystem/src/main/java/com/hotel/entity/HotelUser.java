package com.hotel.entity;

public class HotelUser {
    private Integer hotelUserId;

    private String hotelUserAccount;

    private String hotelUserPwd;

    private String hotelUserName;

    private String hotelUserGender;

    private String hotelUserPhone;

    private String hotelUserImg;

    public String getHotelUserImg() { return hotelUserImg; }

    public void setHotelUserImg(String hotelUserImg) { this.hotelUserImg = hotelUserImg; }

    public Integer getHotelUserId() {
        return hotelUserId;
    }

    public void setHotelUserId(Integer hotelUserId) {
        this.hotelUserId = hotelUserId;
    }

    public String getHotelUserAccount() {
        return hotelUserAccount;
    }

    public void setHotelUserAccount(String hotelUserAccount) {
        this.hotelUserAccount = hotelUserAccount == null ? null : hotelUserAccount.trim();
    }

    public String getHotelUserPwd() {
        return hotelUserPwd;
    }

    public void setHotelUserPwd(String hotelUserPwd) {
        this.hotelUserPwd = hotelUserPwd == null ? null : hotelUserPwd.trim();
    }

    public String getHotelUserName() {
        return hotelUserName;
    }

    public void setHotelUserName(String hotelUserName) {
        this.hotelUserName = hotelUserName == null ? null : hotelUserName.trim();
    }

    public String getHotelUserGender() {
        return hotelUserGender;
    }

    public void setHotelUserGender(String hotelUserGender) {
        this.hotelUserGender = hotelUserGender == null ? null : hotelUserGender.trim();
    }

    public String getHotelUserPhone() {
        return hotelUserPhone;
    }

    public void setHotelUserPhone(String hotelUserPhone) {
        this.hotelUserPhone = hotelUserPhone;
    }
}
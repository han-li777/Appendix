package com.hotel.entity;

public class HotelInfo {
    private Integer hotelInfoId;

    private String hotelInfoName;

    private String hotelInfoAddress;

    private String hotelInfoImg;

    public Integer getHotelInfoId() {
        return hotelInfoId;
    }

    public void setHotelInfoId(Integer hotelInfoId) {
        this.hotelInfoId = hotelInfoId;
    }

    public String getHotelInfoName() {
        return hotelInfoName;
    }

    public void setHotelInfoName(String hotelInfoName) {
        this.hotelInfoName = hotelInfoName == null ? null : hotelInfoName.trim();
    }

    public String getHotelInfoAddress() {
        return hotelInfoAddress;
    }

    public void setHotelInfoAddress(String hotelInfoAddress) {
        this.hotelInfoAddress = hotelInfoAddress == null ? null : hotelInfoAddress.trim();
    }

    public String getHotelInfoImg() {
        return hotelInfoImg;
    }

    public void setHotelInfoImg(String hotelInfoImg) {
        this.hotelInfoImg = hotelInfoImg == null ? null : hotelInfoImg.trim();
    }
}
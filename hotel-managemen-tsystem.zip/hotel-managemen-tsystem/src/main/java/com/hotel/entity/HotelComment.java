package com.hotel.entity;

public class HotelComment {
    private Integer hotelCommentId;
    private String hotelCommentRoomNum;
    private String hotelCommentUser;
    private Integer hotelCommentMemberId;
    private Float hotelCommentScore;
    private String hotelCommentContent;
    private String hotelCommentTime;

    public void setHotelCommentId(Integer hotelCommentId) {
        this.hotelCommentId = hotelCommentId;
    }
    public Integer getHotelCommentId() { return this.hotelCommentId; }

    public void setHotelCommentRoomNum(String hotelCommentRoomNum) {
        this.hotelCommentRoomNum = hotelCommentRoomNum;
    }
    public String getHotelCommentRoomNum() { return this.hotelCommentRoomNum; }

    public void setHotelCommentUser(String hotelCommentUser) {
        this.hotelCommentUser = hotelCommentUser;
    }
    public String getHotelCommentUser() { return this.hotelCommentUser; }

    public void setHotelCommentMemberId(Integer hotelCommentMemberId) {
        this.hotelCommentMemberId = hotelCommentMemberId;
    }
    public Integer getHotelCommentMemberId() { return this.hotelCommentMemberId; }

    public void setHotelCommentScore(Float hotelCommentScore) {
        this.hotelCommentScore = hotelCommentScore;
    }
    public Float getHotelCommentScore() { return this.hotelCommentScore; }

    public void setHotelCommentContent(String hotelCommentContent) {
        this.hotelCommentContent = hotelCommentContent;
    }
    public String getHotelCommentContent() { return this.hotelCommentContent; }

    public void setHotelCommentTime(String hotelCommentTime) {
        this.hotelCommentTime = hotelCommentTime;
    }
    public String getHotelCommentTime() { return this.hotelCommentTime; }
}

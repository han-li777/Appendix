package com.hotel.entity;

public class HotelMemberRoom {
    private Integer hotelMemberRoomId;

    private String hotelMemberRoomUser;

    private String hotelMemberRoomRoomNum;

    private Integer hotelMemberRoomInfoId;

    private String hotelRoomNum;
    private String hotelRoomPwd;
    private String hotelRoomIsPay;
    private String hotelInfoName;
    private String hotelInfoImg;
    private String hotelInfoAddress;
    private String hotelInfoId;

    private String hotelMemberRoomStartTime;

    private String hotelMemberRoomEndTime;

    private String hotelMemberRoomState;

    private String hotelMemberRoomMobile;

    private String hotelMemberRoomIdcard;

    private Float hotelMemberRoomPrice;

    public String getHotelMemberRoomMobile() { return hotelMemberRoomMobile; }

    public void setHotelMemberRoomMobile(String hotelMemberRoomMobile) {
        this.hotelMemberRoomMobile = hotelMemberRoomMobile;
    }

    public String getHotelMemberRoomIdcard() { return hotelMemberRoomIdcard; }

    public void setHotelMemberRoomIdcard(String hotelMemberRoomIdcard) {
        this.hotelMemberRoomIdcard = hotelMemberRoomIdcard;
    }

    public Float getHotelMemberRoomPrice() { return this.hotelMemberRoomPrice; }
    public void setHotelMemberRoomPrice(Float price) {this.hotelMemberRoomPrice = price; }

    public Integer getHotelMemberRoomId() {
        return hotelMemberRoomId;
    }

    public void setHotelMemberRoomId(Integer hotelMemberRoomId) {
        this.hotelMemberRoomId = hotelMemberRoomId;
    }

    public String getHotelMemberRoomUser() {
        return hotelMemberRoomUser;
    }

    public void setHotelMemberRoomUser(String hotelMemberRoomUser) {
        this.hotelMemberRoomUser = hotelMemberRoomUser == null ? null : hotelMemberRoomUser.trim();
    }

    public String getHotelMemberRoomRoomNum() {
        return hotelMemberRoomRoomNum;
    }

    public void setHotelMemberRoomRoomNum(String hotelMemberRoomRoomNum) {
        this.hotelMemberRoomRoomNum = hotelMemberRoomRoomNum == null ? null : hotelMemberRoomRoomNum.trim();
    }

    public Integer getHotelMemberRoomInfoId() {
        return hotelMemberRoomInfoId;
    }

    public void setHotelMemberRoomInfoId(Integer hotelMemberRoomInfoId) {
        this.hotelMemberRoomInfoId = hotelMemberRoomInfoId;
    }

    public String getHotelRoomNum() {
        return hotelRoomNum;
    }

    public void setHotelRoomNum(String hotelRoomNum) {
        this.hotelRoomNum = hotelRoomNum;
    }

    public String getHotelRoomPwd() {
        return hotelRoomPwd;
    }

    public void setHotelRoomPwd(String hotelRoomPwd) {
        this.hotelRoomPwd = hotelRoomPwd;
    }

    public String getHotelRoomIsPay() {
        return hotelRoomIsPay;
    }

    public void setHotelRoomIsPay(String hotelRoomIsPay) {
        this.hotelRoomIsPay = hotelRoomIsPay;
    }

    public String getHotelInfoName() {
        return hotelInfoName;
    }

    public void setHotelInfoName(String hotelInfoName) {
        this.hotelInfoName = hotelInfoName;
    }

    public String getHotelInfoImg() {
        return hotelInfoImg;
    }

    public void setHotelInfoImg(String hotelInfoImg) {
        this.hotelInfoImg = hotelInfoImg;
    }

    public String getHotelInfoAddress() {
        return hotelInfoAddress;
    }

    public void setHotelInfoAddress(String hotelInfoAddress) {
        this.hotelInfoAddress = hotelInfoAddress;
    }

    public String getHotelInfoId() {
        return hotelInfoId;
    }

    public void setHotelInfoId(String hotelInfoId) {
        this.hotelInfoId = hotelInfoId;
    }

    public String getHotelMemberRoomStartTime() {
        return hotelMemberRoomStartTime;
    }

    public void setHotelMemberRoomStartTime(String hotelMemberRoomStartTime) {
        this.hotelMemberRoomStartTime = hotelMemberRoomStartTime;
    }

    public String getHotelMemberRoomEndTime() {
        return hotelMemberRoomEndTime;
    }

    public void setHotelMemberRoomEndTime(String hotelMemberRoomEndTime) {
        this.hotelMemberRoomEndTime = hotelMemberRoomEndTime;
    }

    public String getHotelMemberRoomState() {
        return hotelMemberRoomState;
    }

    public void setHotelMemberRoomState(String hotelMemberRoomState) {
        this.hotelMemberRoomState = hotelMemberRoomState;
    }
}
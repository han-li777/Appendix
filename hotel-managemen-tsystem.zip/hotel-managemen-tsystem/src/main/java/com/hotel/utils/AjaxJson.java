package com.hotel.utils;

import java.util.Map;

/**
 * 返回信息
 * @ClassName: AjaxJson
 * @Description: 返回消息
 */
public class AjaxJson {

	/** 是否成功 */
	private boolean success = true;
	/**提示信息*/
	private String msg = "操作成功";
	/**其他信息*/
	private Object obj = null;
	/**其他参数*/
	private Map<String, Object> attributes;
	/**总条数（配合前端）*/
	private Integer count ;
	
	public Map<String, Object> getAttributes() {
		return attributes;
	}
	/**其他参数*/
	public void setAttributes(Map<String, Object> attributes) {
		this.attributes = attributes;
	}

	public String getMsg() {
		return msg;
	}
	/**提示信息*/
	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Object getObj() {
		return obj;
	}
	/**其他信息*/
	public void setObj(Object obj) {
		this.obj = obj;
	}
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}

}

package com.hotel.utils;

public class UploadResult {
    private Boolean valid;
    private String msg;
    private String url;

    public Boolean getValid() { return valid; }
    public void setValid(Boolean valid) { this.valid = valid; }
    public String getMsg() { return msg; }
    public void setMsg(String msg) { this.msg = msg; }
    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
}

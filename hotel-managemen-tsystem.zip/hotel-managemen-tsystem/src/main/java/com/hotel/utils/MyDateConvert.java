package com.hotel.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MyDateConvert {
    public static String dateToDotStr(Date date)
    {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
        return sdf.format(date);
    }

    public static String dotStrToEn(String dotStr)
    {
        Date dd = dotStrToDate(dotStr);
        if(dd == null)
            return null;
        SimpleDateFormat df = new SimpleDateFormat("dd MMM,yyyy", Locale.UK);
        //df.setTimeZone(new java.util.SimpleTimeZone(0, "GMT"));
        return df.format(dd);
    }

    public static Date dotStrToDate(String dotStr) {
        try
        {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
            return sdf.parse(dotStr);
        }catch (ParseException ex)
        {
            return null;
        }
    }
}

package com.hotel.mapper;

import com.hotel.entity.HotelComment;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface HotelCommentMapper {
    int deleteByPrimaryKey(Integer hotelCommentId);
    int insert(HotelComment hotelComment);
    List<HotelComment> getCommentListByRoomNum(@Param("hotelCommentRoomNum") String hotelCommentRoomNum);
}

package com.hotel.mapper;

import com.hotel.entity.HotelMemberRoom;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface HotelMemberRoomMapper {
    int deleteByPrimaryKey(Integer hotelMemberRoomId);

    int insert(HotelMemberRoom record);

    int insertSelective(HotelMemberRoom record);

    HotelMemberRoom selectByPrimaryKey(Integer hotelMemberRoomId);

    int updateByPrimaryKeySelective(HotelMemberRoom record);

    int updateByAccountRoom(HotelMemberRoom record);

    int updateByPrimaryKey(HotelMemberRoom record);

    List<HotelMemberRoom> findHotelMemberRoomInfo(@Param("hotelUserAccount") String hotelUserAccount);

    List<HotelMemberRoom> getAllList(@Param("hotelUserAccount") String hotelUserAccount);

    List<HotelMemberRoom> getRoomBookings(@Param("roomNum") String roomNum);
    List<HotelMemberRoom> getRoomInUseBookings(@Param("roomNum") String roomNum);
}
package com.hotel.mapper;

import com.hotel.entity.HotelRoom;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface HotelRoomMapper {
    int deleteByPrimaryKey(Integer hotelRoomId);

    int insert(HotelRoom record);

    int insertSelective(HotelRoom record);

    HotelRoom selectByPrimaryKey(Integer hotelRoomId);

    int updateByPrimaryKeySelective(HotelRoom record);

    int updateByPrimaryKey(HotelRoom record);

    List<HotelRoom> getRoomListByHotelRoomInfoId(@Param("hotelRoomInfoId") Integer hotelRoomInfoId);

    void updateByRoomNum(HotelRoom hotelRoom);

    List<HotelRoom> getAllList(@Param("hotelRoomInfoId") Integer hotelRoomInfoId,
                               @Param("hotelRoomNum") String hotelRoomNum);
}
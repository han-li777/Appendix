package com.hotel.mapper;

import com.hotel.entity.ManageAccount;
import org.apache.ibatis.annotations.Param;

public interface ManageAccountMapper {
    int checkManageLogin(ManageAccount manageAccount);
}

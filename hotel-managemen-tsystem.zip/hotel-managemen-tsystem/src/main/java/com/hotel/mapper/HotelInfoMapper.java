package com.hotel.mapper;

import com.hotel.entity.HotelInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface HotelInfoMapper {
    int deleteByPrimaryKey(Integer hotelInfoId);

    int insert(HotelInfo record);

    int insertSelective(HotelInfo record);

    HotelInfo selectByPrimaryKey(Integer hotelInfoId);

    int updateByPrimaryKeySelective(HotelInfo record);

    int updateByPrimaryKey(HotelInfo record);

    List<HotelInfo> getRoomListByHotelRoomInfoId();

    int getRoomEmptyCount(Integer hotelRoomInfoId);

    List<HotelInfo> getAllList(@Param("hotelInfoName") String hotelInfoName);
}
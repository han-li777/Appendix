package com.hotel.mapper;

import com.hotel.entity.HotelUser;
import org.apache.ibatis.annotations.Param;
import java.util.List;

public interface HotelUserMapper {
    int deleteByPrimaryKey(Integer hotelUserId);

    int insert(HotelUser record);

    int insertSelective(HotelUser record);

    HotelUser selectByPrimaryKey(Integer hotelUserId);

    int updateByPrimaryKeySelective(HotelUser record);

    int updateByPrimaryKey(HotelUser record);

    HotelUser getUserByhotelUserAccount(@Param("hotelUserAccount") String hotelUserAccount);

    List<HotelUser> getAllList(@Param("hotelUserName") String hotelUserName);
}
package com.hotel.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class ManageLoginConfig implements WebMvcConfigurer {
    @Override
    public void addInterceptors(InterceptorRegistry registry ){
        InterceptorRegistration registration = registry.addInterceptor(new ManageInterceptor());
        registration.addPathPatterns("/manage/**");
        registration.excludePathPatterns(
                "/manage/login",
                "/manage/checkLogin",
                "/manage/upload");
    }
}
